plot.future <-
function(fres0,ylim.tmp=NULL,xlim.tmp=NULL,vpares=NULL,what=c(TRUE,TRUE,TRUE),
                        label=c("Biomass","SSB","Catch"),is.legend=TRUE,add=FALSE,col=NULL){
  if(is.null(col)) col <- 1                        
  matplot2 <- function(x,add=FALSE,...){
    if(add==FALSE) matplot(rownames(x),x,type="l",lty=c(2,1,2),col=col,xlab="Year",...)
    if(add==TRUE) matpoints(rownames(x),x,type="l",lty=c(2,1,2),col=col,xlab="Year",...)    
  }

  if(is.null(xlim.tmp)) xlim.tmp <- range(as.numeric(colnames(fres0$naa)))

  if(what[1]){
    matplot2(x <- t(apply(fres0$vbiom,1,quantile,probs=c(0.1,0.5,0.9))),
           ylim=c(0,ifelse(is.null(ylim.tmp),max(x),ylim.tmp[1])),
           xlim=xlim.tmp,
           ylab=label[1],main=label[1],add=add)
    points(rownames(fres0$vbiom),apply(fres0$vbiom,1,mean),type="b",pch=1)
    points(rownames(fres0$vbiom),as.numeric(fres0$vbiom[,1]),type="b",pch=3)
    if(!is.null(vpares)){
      points(colnames(vpares$baa),colSums(vpares$baa),type="o",pch=20)
    }
  }

  if(what[2]){
    matplot2(x <- t(apply(fres0$vssb,1,quantile,probs=c(0.1,0.5,0.9))),
             ylim=c(0,ifelse(is.null(ylim.tmp),max(x),ylim.tmp[2])),
             xlim=xlim.tmp,           
             ylab=label[2],main=label[2],add=add)
    points(rownames(fres0$vssb),apply(fres0$vssb,1,mean),type="b",pch=1)    
    points(rownames(fres0$vssb),as.numeric(fres0$vssb[,1]),type="b",pch=3)    
    if(!is.null(vpares)){
      points(colnames(vpares$ssb),colSums(vpares$ssb),type="o",pch=20)
    }
  }

  if(what[3]){
    matplot2(x <- t(apply(fres0$vwcaa,1,quantile,probs=c(0.1,0.5,0.9))),
             ylim=c(0,ifelse(is.null(ylim.tmp),max(x),ylim.tmp[3])),
             xlim=xlim.tmp,           
             ylab=label[3],main=label[3],add=add)
    points(rownames(fres0$vwcaa),apply(fres0$vwcaa,1,mean),type="b",pch=1)        
    points(rownames(fres0$vwcaa),as.numeric(fres0$vwcaa[,1]),type="b",pch=3)        
    if(!is.null(vpares)){
      points(colnames(vpares$baa),colSums(vpares$input$dat$caa*vpares$input$dat$waa),type="o",pch=20)
    }
  }
  if(is.legend){
    plot(1:10,type = "n",ylab = "", xlab = "", axes = F)
    legend("topleft",lty=c(1,1,1,2),legend=c("Deterministic","Mean","Median","80%conf"),pch=c(3,1,NA,NA))
  }
  
}
