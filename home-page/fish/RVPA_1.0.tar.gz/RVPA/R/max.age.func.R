max.age.func <-
function(x) max(which(!is.na(x)))
