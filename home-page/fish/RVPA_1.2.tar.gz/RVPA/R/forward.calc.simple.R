forward.calc.simple <-
function(fav,nav,Mv,plus.group=TRUE){
  nage <- max(which(!is.na(nav)))#length(fav)
  naa <- rep(NA,nage)
  for(a in 2:(nage-1)){
    naa[a] <- nav[a-1]*exp(-fav[a-1]-Mv[a-1])
  }
  naa[nage] <- nav[nage-1]*exp(-fav[nage-1]-Mv[nage-1]) 
  pg <- nav[nage]*exp(-fav[nage]-Mv[nage])
  if(plus.group) naa[nage] <- naa[nage] + pg

  return(naa)
}
