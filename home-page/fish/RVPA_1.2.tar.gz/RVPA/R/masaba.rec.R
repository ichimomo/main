masaba.rec <-
function(ssb,vpares,
                       rec.arg=list(rps.years=list(1970:1985,1986:2011), # year < Blim, year > Blim # rps.year�ł͂Ȃ��C"s"����
                         Blim.rec=450,upper.ssb=1380*1000,
												 rps.years.med=NULL, # RPSmed�̊��Ԃ�rps.years�Ŏw�肵���S���ԂƈقȂ�ꍇ
                         upper.recruit=14200),
                       deterministic=FALSE,rec.resample=NULL
                           ){ 
  if(is.null(rec.arg$rps.years.med)) rec.arg$rps.years.med <- unique(unlist(rec.arg$rps.years))
  
  if(is.null(rec.resample)|deterministic){
    allyears <- as.numeric(dimnames(vpares$naa)[[2]])      
    SSB <- apply(vpares$ssb,2,sum,na.rm=T)      
    rec <- vpares$naa[1,]
    rps <- rec/SSB
	  # define overall RPSmed 
    rps.range.med <- as.numeric(rps[allyears %in% rec.arg$rps.years.med])
    rps.med.all <- median(rps.range.med)

    # define rps ratio for resampling
#    years <- c(rec.arg$rps.years[[1]],rec.arg$rps.years[[2]])
#    rps.range <- as.numeric(rps[allyears %in% years])
#    rps.med <- median(rps.range)
#    rps.mean <- mean(rps.range)  
#    tmp <- rps.range/rps.mean*rps.med.all  
    rps.range <- as.numeric(rps[allyears %in% rec.arg$rps.years[[1]]])
    resample1 <- rps.range/mean(rps.range) * rps.med.all
    rps.range <- as.numeric(rps[allyears %in% rec.arg$rps.years[[2]]])    
    resample2 <- rps.range/mean(rps.range) * rps.med.all
    rec.resample <- list(resample1=resample1,resample2=resample2)
    rps <-  rps.med.all
  }
  if(deterministic){
    rps <-  rps.med.all
  }
  else{
    if(ssb/1000>rec.arg$Blim.rec){
#      rps <- sample(rec.resample[years %in% rec.arg$rps.years[[1]]],1)
      rps <- sample(rec.resample$resample1,1)      
    }
    else{
      #      rps <- sample(rec.resample[years %in% rec.arg$rps.years[[2]]],1)
      rps <- sample(rec.resample$resample2,1)      
    }
  }
  
  ssb.tmp <- min(ssb,rec.arg$upper.ssb)
  rec <- ssb.tmp * rps #sample(rec.resample,1)
  rec2 <- min(rec,rec.arg$upper.recruit)
  return(list(rec=rec2,
              rec.resample=rec.resample))
}
