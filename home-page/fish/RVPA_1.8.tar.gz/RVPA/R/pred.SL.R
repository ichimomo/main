pred.SL <-
function(SSB,a) a*SSB
