pred.RI <-
function(SSB,a,b) a*SSB*exp(-b*SSB)
