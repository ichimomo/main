ff <-
function(x, z) get(x)(z)
