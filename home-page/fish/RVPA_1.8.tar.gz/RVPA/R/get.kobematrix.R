get.kobematrix <-
function(fres,Blim=0,Bban=0,ssb=TRUE){
    if(isTRUE(ssb))  tmp <- fres$vssb[,-1]
    else  tmp <- fres$vbiom[,-1]
    
    res <- data.frame(
        # ���l��
        catch.deterministic=fres$vwcaa[,1],
        # ������
        biom.deterministic=fres$vbiom[,1],
        # �e����
        ssb.deterministic=fres$vssb[,1],
        # Blim�񕜊m��
        probability.upper.Blim=apply(tmp>Blim,1,mean)*100,
        # Bban�ȏ�m��
        probability.upper.Bban=apply(tmp>Bban,1,mean)*100)

    return(res)
}
