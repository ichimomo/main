HS.rec <-
function(ssb,vpares,deterministic=FALSE,rec.resample=NULL,
                           rec.arg=list(a=1000,b=1000,gamma=0.01,sd=0.1,bias.correction=TRUE)){
    if(is.null(rec.arg$gamma)) rec.arg$gamma <- 0.01
    if(is.null(rec.arg$bias.correction)) rec.arg$bias.correction <- TRUE

    rec <- rec.arg$a*(ssb+sqrt(rec.arg$b^2+(rec.arg$gamma^2)/4)-sqrt((ssb-rec.arg$b)^2+(rec.arg$gamma^2)/4))
    if(!isTRUE(deterministic)){
        if(isTRUE(rec.arg$bias.correction)){
            rec <- rec*exp(rnorm(length(ssb),-0.5*(rec.arg$sd)^2,rec.arg$sd))
            }
        else{
            rec <- rec*exp(rnorm(length(ssb),0,rec.arg$sd))
            }
    }
  return(list(rec=rec,rec.resample=1))
}
