allplot <-
function(res0,target="hs",N.unit=1,pngfile="../buri.png",detail.plot=1:3){
    dmodel <- res0$vpares
    summary <- res0$summary[rownames(res0$summary)=="hs",]
    res00 <- res0[target][[1]]
    if(is.null(dmodel$Bban))  dmodel$Bban <- NA
    if(is.null(dmodel$Blimit))  dmodel$Blimit <- NA
    if(is.null(dmodel$ABC))  dmodel$ABC <- NA
#    summary$Bban <- dmodel$Bban
    summary[1] <- res00$r0
    colnames(summary)[1] <- "R0"
    summary$Blimit <- ifelse(length(dmodel$Blimit)>0,dmodel$Blimit,NA)
    summary$"Fmsy/Fcurrent" <- res00$f.msy
    summary$ABC2017 <- dmodel$ABC2017
    summary$ABC2015 <- dmodel$ABC2015    
    summary$"newABC2015" <- rev(colSums(dmodel$baa))[1] * summary$"U_MSY"

    summary$"Pr(SSB_2021>SSB_MSY) (%)" <- mean(res00$fout[[1]]$vssb[6,]>summary$"SSB_MSY")*100
    summary$"Pr(SSB_2021>SSB_hs) (%)" <- mean(res00$fout[[1]]$vssb[6,]>summary$"b")*100

    colnames(summary)[2] <- "SSB_HS"
    colnames(summary)[8:9] <- c("SSB0","B0")

    
    summary1 <- data.frame(parameter=names(summary),value=as.numeric(summary))

    ## currentF projection
    arg.tmp <- res0$hs$farg
    arg.tmp$multi <- 1
    fout0 <- do.call(future.vpa2,arg.tmp) # currentF�ł̏����\���̌���
    fout1 <- res0$hs$fout[[1]] # Fmsy�ł̏����\���̌���

    layout(t(matrix(c(1,2,3,4,5,6,7,8),2,4)),heights=c(0.7,1,1,1))
    
    if(1%in%detail.plot){            
        ## plot talbe
        par(mar=c(1,4.3,3,1))
        n <- floor(nrow(summary1)/2)
        plot.info(summary1[1:n,])
        title(dmodel$jstockid)    
        plot.info(summary1[(n+1):nrow(summary1),])    
       
        ## SR plot(all)
        par(mar=c(4.3,4.3,3,1))
        aa <- summary[c("SSB_MSY","Blimit","SSB_HS")]    
        fit.tmp <- plot.SR(res0,what.plot=rownames(res0$summary),pick="SSB_MSY",xyscale=c(1.8,1.3))
#        abline(v=aa,col=c("chartreuse3","orange","red"))
        title("R vs SSB (HS, BH, RI)")

        ## SR plot(HS)
        par(mar=c(4.3,4.3,3,1))
        aa <- summary[c("SSB_MSY","Blimit","SSB_HS")]    
        fit.tmp <- plot.SR(res0,what.plot="hs",pick="SSB_MSY",xyscale=c(1.8,1.3),is.legend=FALSE)
#        abline(v=aa,col=c("chartreuse3","orange","red"))
        title("R vs SSB (only HS)")        

        ## Residual plot
        plot(x <- res0$dat$year,
             y <- fit.tmp$resid[[1]],
             ylim=c(-1.5,1.5),type="p",pch=20,xlab="Year",ylab="log(Obs)-log(Pred)")
        abline(h=0,lty=2)
        xx <- loess(y~x)
        points(x,xx$fitted,type="l",col=2,lwd=2)
        title("Residual to HS prediction")

        ## plot diagnostics
        if(target=="hs"){
            show.likeprof(res0)
            lines(c(res0$hs$b,res0$hs$b),quantile(res0$hs$boot$a,probs=c(0.05,0.95)))
            lines(quantile(res0$hs$boot$b,probs=c(0.05,0.95)),c(res0$hs$a,res0$hs$a))
            points(res0$hs$jack$b,res0$hs$jack$a)
            legend("topleft",lty=c(1,NA),pch=c(NA,1),legend=c("Bootstrap 90%", "Jackknife"),ncol=2,bg="white")
        }

        ## yield curve
        par(mar=c(4.3,4.3,3,4.3))
        plotyield(res0)

    }

    if(2%in%detail.plot){
        layout(t(matrix(c(1,2,3,4,5,6),2,3)),heights=c(1.2,1,1))        
                                        # Kobe
        par(mar=c(4.3,4.3,5,1))        
        a <- plot.Kobe2(res0,pickU="U_MSY",pickB="SSB_MSY",is.plot=T)
        abline(v=summary$"SSB_HS"/summary$"SSB_MSY",lty=2)
        title("Kobe chart",line=0.5)
        title(dmodel$jstockid,line=2)

        # plot selectivity
        matplot(rownames(res0$vpares$faa),
                res0$vpares$faa,pch=20,col="gray",xlab="Age",ylab="F",ylim=c(0,max(res0$vpares$faa,na.rm=T)))
        points(rownames(res0$vpares$faa),res0$hs$fout[[1]]$faa[,1],type="b")
        legend("topleft",pch=c(1,20),legend=c("Current F","Past Fs"),col=c(1,"gray"))
        title("Current F (2013-2015)")

        ## plot SSB
        par(mar=c(4.3,4.3,3,1))                                
        years <- as.numeric(colnames(dmodel$ssb))
        y <- as.numeric(colSums(dmodel$ssb))
        plot(years,y,ylim=c(0,1.1*max(c(y,unlist(aa)),na.rm=T)),xlab="Years",ylab="SSB",type="o",
             xlim=c(min(years),max(years)+10))

        ## projection
        menplot(rownames(fout0$vssb),t(apply(fout0$vssb,1,quantile,probs=c(0.1,0.9))),
                col=rgb(40/255,96/255,163/255,0.2),border="blue",lty=2)
        menplot(rownames(fout1$vssb),t(apply(fout1$vssb,1,quantile,probs=c(0.1,0.9))),
                col=rgb(40/255,96/255,163/255,0.2),border="red",lty=2)        
        points(rownames(fout0$vssb),apply(fout0$vssb,1,mean),type="o",pch=20,
               col="blue")
        points(rownames(fout1$vssb),apply(fout1$vssb,1,mean),type="o",pch=20,
               col=2)                
        
        abline(h=aa,col=c("chartreuse3","orange","red"))
        legend("topleft",col=c("chartreuse3","orange","red","blue","red"),lty=1,pch=c(NA,NA,NA,20,20),
               legend=c("SSB_MSY","SSB_limit","SSB_HS","Projection (Fcur)","Projection (Fmsy)"),cex=0.8,
               bg="white",ncol=2)
        title("SSB",line=0.5)
        
                                        # plot catch
        y <- as.numeric(colSums(dmodel$input$dat$caa * dmodel$input$dat$waa,na.rm=T)) * N.unit /1000000
        aa <- summary[c("MSY")]
        plot(years,y,ylim=c(0,1.1*max(c(y,unlist(aa)))),xlab="Years",ylab="Total catch",type="o",
             xlim=c(min(years),max(years)+10))

        ## projection
        menplot(rownames(fout0$vssb),t(apply(fout0$vwcaa,1,quantile,probs=c(0.1,0.9))),
                col=rgb(210/255,94/255,44/255,0.3),border="blue",lty=2)
        menplot(rownames(fout1$vssb),t(apply(fout1$vwcaa,1,quantile,probs=c(0.1,0.9))),
                col=rgb(210/255,94/255,44/255,0.3),border="red",lty=2)
        points(rownames(fout0$vssb),apply(fout0$vwcaa,1,mean),type="o",pch=20,
               col="blue")
        points(rownames(fout1$vssb),apply(fout1$vwcaa,1,mean),type="o",pch=20,
               col=2)
        
        abline(h=aa,col="chartreuse3")
        tmp <- names(summary)%in%c("ABC2017","ABC2015","newABC2015")
        points(c(2017,2015,2015),summary[tmp],pch=c(3,2,1),col=c(1,1,2))
        points(c(2017,2015,2015),summary[tmp],pch=c(3,2,1),col=c(1,1,2))
        legend("topleft",col=c("chartreuse3",1,1,2,"blue","red"),bg="white",
               pch=c(NA,3,2,1,20,20),legend=c("MSY","ABC2017","ABC2015","newABC2015","Projection (Fcur)","Projection (Fmsy)"),ncol=2,cex=0.8,
               lty=c(1,NA,NA,NA,1,1))


        
        title("Catch")    
        
                                        # plot exploitation rates
        y <- y/as.numeric(colSums(dmodel$baa))
        aa <- summary[c("U_MSY")]
        plot(years,y,ylim=c(0,1.1*max(c(y,unlist(aa)))),xlab="Years",ylab="Exploitation rates (Catch/B)",type="o",
             xlim=c(min(years),max(years)+10))

        # projection
        points(rownames(fout0$vssb),apply(fout0$vwcaa,1,mean)/apply(fout0$vbiom,1,mean),type="o",pch=20,
               col="blue")
        points(rownames(fout1$vssb),apply(fout1$vwcaa,1,mean)/apply(fout1$vbiom,1,mean),type="o",pch=20,
               col=2)

        
        abline(h=aa,col=c("chartreuse3"))
        legend("topright",col=c("chartreuse3"),lty=1,legend=c("U_MSY"))
        title("Exploitation rates (U)")

        ## plot %SPR
        y <- dmodel$SPR$ysdata$perSPR
        plot(years,y,ylim=c(0,100),xlab="Years",ylab="%SPR",type="o",
             xlim=c(min(years),max(years)))

        aa <- summary[c("SSB_MSY","SSB0")]                    
        abline(h=aa[1]/aa[2]*100,col=c("chartreuse3"))
        legend("topright",col=c("chartreuse3"),lty=1,legend=c("SSB_MSY/SSB0"))
        title("%SPR")
        
    }

    if(3%in%detail.plot){        
        layout(t(matrix(c(1,2,3,3,4,4,5,5),2,4)),heights=c(1,2,1,1))
        tres0 <- res0$hs$trace[[1]]
        ssb <- res0$hs$trace[[1]]$ssb.mean/1000
        tmp <- substr(colnames(tres0),1,5)=="TB-MA"
        tb <- tres0[,tmp]/1000
        tb2 <- sapply(1:ncol(tb),function(x) apply(tb[,1:x,drop=F],1,sum,na.rm=T))
        tmp <- substr(colnames(tres0),1,5)=="TC-MA"
        tc <- tres0[,tmp]/1000
        tc2 <- sapply(1:ncol(tc),function(x) apply(tc[,1:x,drop=F],1,sum,na.rm=T))
        library(png)
        if(file.exists(pngfile)) image <- readPNG(pngfile)
        else image <- NULL

#        library(RColorBrewer)
#        if(ncol(tc)<10)    col.tmp <- brewer.pal(ncol(tc),"Greens")
#        else col.tmp <- c(brewer.pal(9,"Greens"),rev(brewer.pal(ifelse(ncol(tc)-9<3,3,ncol(tc)-9),"GnBu")))
        col.tmp1 <- rgb(40/255,96/255,163/255,seq(from=0.1,to=0.9,length=ncol(tc)))
        col.tmp2 <- rgb(210/255,94/255,44/255,seq(from=0.1,to=0.9,length=ncol(tc)))                        

        ## plot table
        par(mar=c(1,4.3,3,2))
        plot.info(summary1[c(2,4,5,6,10,11,12,14),])    
        title(dmodel$jstockid)

        plot.SR(res0,what.plot="hs",pick="SSB_MSY",xyscale=c(1.8,1.3),
                is.legend=FALSE)    

        par(mar=c(2,4.3,3,4.3))    
        scale <- max(ssb,na.rm=T) * 0.1
                                        #    ysize <- max(ssb,na.rm=T)/max(tb,na.rm=T)
        year.tmp <- rev(colnames(res0$vpares$ssb))[1:5]
        range1 <- range(res0$vpares$ssb)/1000
        range2 <- range(as.data.frame(res0$vpares$ssb)[as.character(year.tmp)])/1000


        ### plot of SSB
        ssb.max <- max(c(range1,summary$"SSB_MSY"),na.rm=T) *1.5 /1000
        tb3 <- tb2[which(ssb<ssb.max),]
        matplot(ssb,tb2,type="n",xlab="",ylab="Biomass (1000MT)",xaxs="i",yaxs="i",
                ylim=c(0,max(tb2[which(ssb<ssb.max),])*1.2),xlim=c(0,ssb.max))    
                                        #    menplot(range1,cbind(c(-100,-100),rep(max(tb2)*1.5,2)),col=gray(0.9),border=NA)
                                        #    menplot(range2,cbind(c(-100,-100),rep(max(tb2)*1.5,2)),col=gray(0.7),border=NA)
        non.na <- !is.na(ssb)
        for(i in 1:ncol(tb2)) menplot(ssb[non.na], cbind(0,tb2)[non.na,i:(i+1)],col=col.tmp1[i],border=NA)
        waa.tmp <- (apply(res0$vpares$input$dat$waa,1,mean))^(1/3)*10
        waa.tmp <- waa.tmp/max(waa.tmp) * 0.9
        x <- tb3[1,]
        plotfish(image,x=rep(ssb.max*0.88,ncol(tb)),y=x-diff(c(0,x))/2,
                 size=waa.tmp,scale=scale,ysize=1)
        text(rep(ssb.max*0.93,ncol(tb)),x-diff(c(0,x))/2,
             paste(0:(ncol(tb2)-1),"y/o: ",round(apply(res0$vpares$input$dat$waa,1,mean),0),"g"),cex=1)

        matpoints(ssb,tb2[,1],type="l",lwd=2,col="gray",lty=3)
        points(x <- res0$vpares$ssb/1000,
               y <- res0$vpares$baa/1000,type="o",
               col=gray(c(seq(from=0.7,to=0,length=length(x)))),pch=20,cex=1.2,
               lwd=3)
        text(x[1],y[1],colnames(x)[1],adj=0)
        text(rev(x[1]),rev(y)[1],rev(colnames(x))[1],adj=0)
                                        #    browser()    
        abline(v=summary$"SSB_MSY"/1000,lty=2)
        abline(v=summary$"Blimit"/1000,lty=2)
        abline(v=summary$"SSB_HS"/1000,lty=2)            
        text(summary$"SSB_MSY"/1000,max(tb3)*1.1,
             paste("SSB_MSY=",format(round(summary$"SSB_MSY"/1000),big.mark=","),"",sep=""),adj=0)
        text(summary$"Blimit"/1000,max(tb3)*1.0,
             paste("SSB_limit=",format(round(summary$"Blimit"/1000),big.mark=","),
                   "",sep=""),adj=0)
        text(summary$"SSB_HS"/1000,max(tb3)*1.05,
             paste("SSB_HS=",format(round(summary$"SSB_HS"/1000),big.mark=","),
                   "",sep=""),adj=0)
                                        #    text(max(ssb)*0.8,max(tb[,1],na.rm=T)*1.05,"�\��������",col=2)
        ## plot of SSB CV
        par(new=T)
        y <- res0$hs$trace[[1]]$ssb.CV
        plot(ssb,y,type="l",lwd=3,col=rgb(0.8,0.8,0,0.6),axes=F,xlab="",ylab="",
             ylim=c(0,ifelse(max(y,na.rm=T)>1.5,1.5,max(y,na.rm=T))))
        axis(side=4)
        mtext(side=4,"CV of SSB",line=3,col=rgb(0.8,0.8,0,0.6),cex=0.8)
        
        ##  catch
        par(mar=c(2,4.3,1,4.3))
        wcatch <- as.numeric(colSums(res0$vpares$input$dat$caa * res0$vpares$input$dat$waa/1000000/1000,na.rm=T))
        matplot(ssb,tc2,type="n",,xaxs="i",yaxs="i",ylab="Catch (1000MT)",
                                        #            ylim=c(0,max(tc2,wcatch)*1.2),xlim=c(0,ssb.max))
                ylim=c(0,max(tc2)*1.2),xlim=c(0,ssb.max))

                                        #    menplot(range1,cbind(c(-100,-100),rep(max(tb2)*1.5,2)),col=gray(0.9),border=NA)
                                        #    menplot(range2,cbind(c(-100,-100),rep(max(tb2)*1.5,2)),col=gray(0.7),border=NA)    
        scale <- max(ssb)/max(tc2)
        for(i in 1:ncol(tc2)) menplot(ssb[non.na], cbind(0,tc2)[non.na,i:(i+1)],col=col.tmp2[i],border=NA)
        abline(v=summary$"SSB_MSY"/1000,lty=2)
        abline(v=summary$"Blimit"/1000,lty=2)
        abline(v=summary$"SSB_HS"/1000,lty=2)                    
        points(x <- as.numeric(res0$vpares$ssb)/1000,
               y <- wcatch,pch=20,lwd=3,
               type="o",col=gray(c(seq(from=0.7,to=0,length=length(x)))))
        text(x[1],y[1],colnames(res0$vpares$ssb)[1],adj=0)
        text(rev(x)[1],rev(y)[1],rev(colnames(res0$vpares$ssb))[1],adj=0)
        points(x <- apply(res0$hs$fout[[1]]$vssb,1,mean)[1:10]/1000,
               y <- apply(res0$hs$fout[[1]]$vwcaa,1,mean)[1:10]/1000,col=2,
               type="o",pch=20,lwd=3)
        text(rev(x)[1],rev(y)[1],
             paste("Projection ",rownames(res0$hs$fout[[1]]$vssb)[10],"(F_MSY)",sep=""),adj=-0.1,col=2)

        points(x <- apply(fout0$vssb,1,mean)[1:10]/1000,
               y <- apply(fout0$vwcaa,1,mean)[1:10]/1000,col="blue",type="o",pch=20,lwd=3)
        text(rev(x)[1],rev(y)[1],
             paste("Projection ",rownames(res0$hs$fout[[1]]$vssb)[10],"(F_current)",sep=""),adj=-0.1,col="blue")

        ## plot of catch CV
        par(new=T)
        y <- res0$hs$trace[[1]]$catch.CV
        plot(ssb,y,type="l",lwd=2,col=rgb(0.8,0.8,0,0.6),axes=F,xlab="",ylab="",
             ylim=c(0,ifelse(max(y,na.rm=T)>1.5,1.5,max(y,na.rm=T))))
        axis(side=4)
        mtext(side=4,"CV of Catch",line=3,col=rgb(0.8,0.8,0,0.6),cex=0.8)        
        
        ## �w�͗� plot
        par(mar=c(4.3,4.3,2,4.3))
        tmp <- round(ssb*1000)>0 & !is.na(ssb)
        matplot(ssb,tres0$fmulti,type="n",ylab="Fishing efforts (current=1)",xaxs="i",yaxs="i",xlab="SSB(1000MT)",xlim=c(0,ssb.max),
                ylim=c(0,max(tres0$fmulti[tmp]*1.2)))
                                        #    menplot(range1,cbind(c(-100,-100),rep(max(tb2)*1.5,2)),col=gray(0.9),border=NA)
                                        #    menplot(range2,cbind(c(-100,-100),rep(max(tb2)*1.5,2)),col=gray(0.7),border=NA)
        menplot(ssb[tmp],cbind(0,tres0$fmulti[tmp]),col=rgb(221/255,159/255,33/255,0.5),border=NA)
        points(x <- as.numeric(res0$vpares$ssb)/1000,
               y <- res0$hs$Fhist[[1]]$fmulti,pch=20,lwd=3,
               type="o",col=gray(c(seq(from=0.7,to=0,length=length(x)))))
        abline(h=1,lty=2)
        abline(v=summary$"SSB_MSY"/1000,lty=2)
        abline(v=summary$"Blimit"/1000,lty=2)
        abline(v=summary$"SSB_HS"/1000,lty=2)                            
                                        #    points(x <- ssb[which.min(abs(tres0$fmulti-1))],y <- tres0$fmulti[which.min(abs(tres0$fmulti-1))],pch=4)
                                        #    text(x,y,"Recent 3 years",adj=-0.1)

    }
    else{
        a <- NULL
    }

    Fcurrent <- list(wcatch=mean(fout0$vwcaa[nrow(fout0$vwcaa),],na.rm=T),
                     ssb=mean(fout0$vssb[nrow(fout0$vssb),],na.rm=T))
    
    invisible(list(a=a,summary=summary,Fcurrent=Fcurrent))
    
}
