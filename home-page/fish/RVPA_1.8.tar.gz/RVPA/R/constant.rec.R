constant.rec <-
function(ssb,vpares,deterministic=FALSE,rec.resample=NULL,
                           rec.arg=list(rec=1000)){ # ������
  ## �Ƃ�ӂ��p; constant recruitment (no stochastic)        
  return(list(rec=rec.arg$rec,rec.resample=1))
}
