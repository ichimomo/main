pred.BH <-
function(SSB,a,b) a*SSB/(1+b*SSB)
