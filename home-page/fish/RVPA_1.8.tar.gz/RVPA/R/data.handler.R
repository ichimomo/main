data.handler <-
function(
  caa,
  waa,
  maa,
  index=NULL,
  M = 0.4,
  maa2=NULL,
  catch.prop=NULL
)
{
  years <- as.numeric(sapply(strsplit(names(caa[1,]),"X"), function(x) x[2]))

  if (is.null(dim(waa)) | dim(waa)[2]==1) waa <- as.data.frame(matrix(unlist(waa), nrow=nrow(caa), ncol=ncol(caa)))
  if (is.null(dim(maa)) | dim(maa)[2]==1) maa <- as.data.frame(matrix(unlist(maa), nrow=nrow(caa), ncol=ncol(caa)))

  colnames(caa) <- colnames(waa) <- colnames(maa) <- years

  if (!is.null(maa2)) {
    if (is.null(dim(maa2)) | dim(maa2)[2]==1) maa2 <- as.data.frame(matrix(unlist(maa2), nrow=nrow(caa), ncol=ncol(caa)))
    colnames(maa2) <- years
  }

  if (!is.null(catch.prop)) colnames(catch.prop) <- years
  
  if (!is.null(index)) colnames(index) <- years

  if (is.null(dim(M))) M <- as.data.frame(matrix(M, nrow=nrow(caa), ncol=ncol(caa)))

  colnames(M) <- years
  rownames(M) <- rownames(caa)

  res <- list(caa=caa, maa=maa, waa=waa, index=index, M=M, maa2=maa2, catch.prop=catch.prop)

  invisible(res)
}
