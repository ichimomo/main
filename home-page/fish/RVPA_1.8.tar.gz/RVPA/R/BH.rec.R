BH.rec <-
function(ssb,vpares,deterministic=FALSE,rec.resample=NULL,
                           rec.arg=list(a=1000,b=1000,sd=0.1,bias.correction=TRUE)){
    if(is.null(rec.arg$bias.correction)) rec.arg$bias.correction <- TRUE
    rec <- rec.arg$a*ssb/(1+rec.arg$b*ssb)
    if(!isTRUE(deterministic)){
        if(isTRUE(rec.arg$bias.correction)){
            rec <- rec*exp(rnorm(length(ssb),-0.5*(rec.arg$sd)^2,rec.arg$sd))
            }
        else{
            rec <- rec*exp(rnorm(length(ssb),0,rec.arg$sd))                
            }
    }
  return(list(rec=rec,rec.resample=1))
}
