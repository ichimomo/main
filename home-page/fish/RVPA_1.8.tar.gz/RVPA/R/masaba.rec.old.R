masaba.rec.old <-
function(ssb,vpares,
                       rec.arg=list(rps.years=list(1970:1985,1986:2011),
                         Blim.rec=450,upper.ssb=1380*1000,
                         upper.recruit=14200),
                       deterministic=FALSE,rec.resample=NULL
                           ){ # ���ϒl�ƒ����l�̔䗦���g������){
  if(is.null(rec.resample)|deterministic){
    years <- as.numeric(dimnames(vpares$naa)[[2]])      
    SSB <- apply(vpares$ssb,2,sum,na.rm=T)      
    rec <- vpares$naa[1,]
    rps <- rec/SSB
    rps.range <- as.numeric(rps[years %in% c(rec.arg$rps.years[[1]],rec.arg$rps.years[[2]])])
    rps.med <- median(rps.range)
    rps.mean <- mean(rps.range)  
    tmp <- rps.range/rps.mean*rps.med  
    resample1 <- tmp[years %in% rec.arg$rps.years[[1]]]
    resample2 <- tmp[years %in% rec.arg$rps.years[[2]]]
    rec.resample <- list(resample1=resample1,resample2=resample2)
    rps <-  rps.med
#    cat("1 ")
  }

  if(deterministic){
    rps <-  rps.med
  }
  else{
    if(ssb/1000>rec.arg$Blim.rec){
#      rps <- sample(rec.resample[years %in% rec.arg$rps.years[[1]]],1)
      rps <- sample(rec.resample$resample1,1)      
    }
    else{
      #      rps <- sample(rec.resample[years %in% rec.arg$rps.years[[2]]],1)
      rps <- sample(rec.resample$resample2,1)      
    }
  }
  
#  browser()
  ssb.tmp <- min(ssb,rec.arg$upper.ssb)
  rec <- ssb.tmp * rps #sample(rec.resample,1)
  rec2 <- min(rec,rec.arg$upper.recruit)
  return(list(rec=rec2,
              rec.resample=rec.resample))
}
