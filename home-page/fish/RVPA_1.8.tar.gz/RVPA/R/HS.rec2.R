HS.rec2 <-
function(ssb,vpares,deterministic=FALSE,rec.resample=NULL,
                           rec.arg=list(a=0.2,b=1000,sd=0.1,
                                        resample=TRUE,
                                        resid=0, # �c���̉ߋ��̎��n��
                                        hssb=0, # SSB�̉ߋ��̎��n��
                                        threshold=c(0, 50000,10000,Inf), # �w�肵��SSB�̂������l�Ń��T���v�����O����c����ς���
                                        nblock=0)){ # block resampling���邩�B��̃I�v�V�����Ɠ����ɂ͂ł��Ȃ�

    if(is.null(rec.arg)) nblock <- 0
    if(is.null(rec.resample)) rec.resample <- list(count=1)
    if(ssb>rec.arg$b) rec <- rec.arg$a*rec.arg$b
    else rec <- rec.arg$a*ssb
    
    if(!isTRUE(deterministic)){
        if(isTRUE(rec.arg$resample)){
            if(is.null(rec.arg$threshold)){
                if(rec.arg$nblock==0){
                                        # normal resampling
                    rec <- exp(log(rec)+sample(rec.arg$resid,1))
                }
                else{ # block resampling
                    rec.resample$sample.year <- ifelse(rec.resample$count==1,
                                                       sample(1:length(rec.arg$resid),1),
                                                       rec.resample$sample.year+1)
                    if(rec.resample$sample.year>length(rec.arg$resid)){
                        rec.resample$sample.year <- rec.resample$sample.year-length(rec.arg$resid)
                    }
                    rec.resample$count <- ifelse(rec.resample$count==rec.arg$nblock,1,rec.resample$count + 1)
                    rec <- exp(log(rec)+rec.arg$resid[rec.resample$sample.year])
                }
            }
            else{   # threshold�ɒl�������Ă���ꍇ
                rset <- tapply(rec.arg$resid,as.numeric(cut(rec.arg$hssb,breaks=rec.arg$threshold)),
                                        function(x) x)
                rec <- exp(log(rec)+sample(rset[[as.numeric(cut(ssb,breaks=rec.arg$threshold))]],1))
            }
        }
        else{
            # ���v���X���z
            require(VGAM)
            phai <- sqrt(var(rec.arg$resid)/2)
       #     if(isTRUE(rec.arg$raplace)){
                rec <- rec * exp(rlaplace(1,0,phai)) #rec*exp(rnorm(length(ssb),-0.5*(rec.arg$sd)^2,rec.arg$sd))

        #    }
        #   else{
        #       rec <- rec*exp(rnorm(length(ssb),-0.5*(phai*2)^2,phai*2)) # �ΐ����K���z
        #     }
        }
    }
  return(list(rec=rec,rec.resample=rec.resample))
}
