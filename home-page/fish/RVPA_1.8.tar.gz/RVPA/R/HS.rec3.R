HS.rec3 <-
function(ssb,vpares,deterministic=FALSE,rec.resample=NULL,
                           rec.arg=list(a=0.2,b=1000,sd=0.1,
                                        resid=0, # �c���̉ߋ��̎��n��
                                        hssb=0, # SSB�̉ߋ��̎��n��
                                        LGRB=lm(rec.arg$resid~log(rec.arg$hssb)))
                                        ){
    HS <- function(x,a,b)  ifelse(x>b,a*b,a*x)

    rec <- exp(log(HS(ssb,rec.arg$a,rec.arg$b)) + predict(lres,data.frame(SSB=ssb)))
    
    if(!isTRUE(deterministic)){
        rec <- rec * exp(sample(lres$resid,1))
    }
  return(list(rec=rec,rec.resample=rec.resample))
}
