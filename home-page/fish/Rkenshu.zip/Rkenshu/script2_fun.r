# �[���f�[�^�����̂��߂̊֐�
SPobs <- function(r, K, B1, E, q, sigma, nyear=50){
  B <- numeric()
  B[1] <- B1
  for(i in 2:nyear){ 
    B[i] <- B[i-1] + r*(1-B[i-1]/K)*B[i-1] - E[i-1]*B[i-1]
  }
  C.obs <- E*B
  cpue.obs <- B * q * 
          exp(rnorm(length(C.obs), mean=0, sd=sigma))
  res <- list(B=B, E=E, C.obs=C.obs, cpue.obs=cpue.obs)
  class(res) <- "SPobs"
  return(res)
}

# CPUE�̗\���l���v�Z����֐�
SPexp <- function(pars, what.est, init, data, nyear=50, B1eqK=FALSE,out=FALSE){ # pars <- c(r, log(K), log(B1), log(q))
  C.obs <- data$C.obs
  cpue.obs <- data$cpue.obs
  tmp <- init
  tmp[what.est] <- pars

  r <- tmp[1]
  K <- exp(tmp[2])
  B1 <- exp(tmp[3])
  if(B1eqK==TRUE) B1 <- exp(tmp[2])
#  q <- exp(tmp[4])

  B <- numeric()
  B[1] <- B1
  for(i in 2:nyear){
    B[i] <- B[i-1] + r*(1-B[i-1]/K)*B[i-1] - C.obs[i]
    B[i] <- ifelse(B[i]<0,0.001,B[i])
  }
  ncpue <- sum(!is.na(cpue.obs))
  q <- exp(1/ncpue* log(cpue.obs/B))
  
  cpue.exp <- q * B
  if(out==TRUE){
    res <- list(B=B, C.obs=C.obs, E=E, cpue.exp=cpue.exp)
    class(res) <- "SPobs"
    return(res)
  }
  else{
    return(sum((log(cpue.exp)-log(cpue.obs))^2,na.rm=T))
  }
}

# �v���_�N�V�������f���Ńp�����[�^�𐄒肷��֐�
SPest <- function(what.est, data,
                  init=c(0.3,1000,1000),B1eqK=FALSE){
  init2 <- init
  init2[2:3] <- log(init[2:3])
  res <- optim(init2[what.est],
               SPexp,
               what.est=what.est,
               data=data,
               B1eqK=B1eqK,
               init=init2,control=list(maxit=10000))
  res$summary <- data.frame(init=init,est=NA)
  res$summary$est[what.est] <- res$par
  res$summary$est[2:3] <- exp(res$summary$est[2:3])
  rownames(res$summary) <- c("r","K","B1")
  res$init2 <- init2
  class(res) <- "SPest"
  res$data <- data
  return(res)
}

# �\���l�̌v�Z
predict.SPest <- function(res,out=TRUE){
  tmp <- SPexp(res$par,what.est=which(!is.na(res$summary$est)),
         init=res$init2,data = res$data,out=out)
  tmp$summary <- res$summary
  return(tmp)
}

print.SPest <- function(res){
  print(round(res$summary,3))
}

# �f�[�^��\���l�̃v���b�g
plot.SPobs <- function(res){
  plot(res$B,type="b",ylab="Biomass",ylim=c(0,max(res$B,res$cpue)))
  points(res$C.obs,type="b",pch=2,col=2)
  points(res$cpue,yaxt="n",xaxt="n",pch=3,col=3,ylim=c(0,max(res$cpue)),xlab="",ylab="")
  legend("topright",col=1:3,pch=1:3,legend=c("Biomass","Catch","CPUE"))
}

# �[���f�[�^�����֐��i�N��\�����f���j
ASobs <- function(nage=10,nyear=50,F=c(seq(from=0.2,to=0.5,length=40),rep(0.5,10)),
                  M=0.3,R0=1000,maturity=c(rep(0,4),rep(1,6)),h=0.7,Rsigma=0,sigma=0.2){
  N <- C <- matrix(0,nage,nyear)
  dimnames(C) <- dimnames(N) <- list(1:nage,1:nyear)
  N.init <- numeric()
  N.init[1] <- R0
  for(i in 2:(nage-1))  N.init[i] <- N.init[i-1]*exp(-M-F[1])
  N.init[nage] <- N.init[nage-1]/(1-exp(-M))
  S0 <- sum(N.init * maturity)
  beverton <- function(h,S0,R0,ssb,sigma=0){
    4*h*R0*ssb/(S0*(1-h)+ssb*(5*h-1)) * exp(rnorm(length(ssb),mean=-0.5*(sigma)^2,sd=sigma))
  }

  N[,1] <- N.init
  for(i in 2:nyear){
    for(j in 2:(nage-1)){
      N[j,i] <- N[j-1,i-1] * exp(-F[i-1]-M)
    }
    N[nage,i] <- N[nage,i-1] * exp(-F[i-1]-M) + N[nage-1,i-1] * exp(-F[i-1]-M)
    N[1,i] <- beverton(sum(N[,i] * maturity),h=h,S0=S0,R0=R0,sigma=Rsigma)
  }

  for(i in 1:nyear){
    C[,i] <- F[i]/(F[i]+M)*N[,i]*(1-exp(-F[i]-M))
  }
  cpue.obs <- colSums(N)*exp(rnorm(nyear,0,sigma))
  
  res <- list(B=colSums(N),C.obs=colSums(C),cpue.obs=cpue.obs,naa=N,caa=C)
  class(res) <- "SPobs"
  return(res)
}
