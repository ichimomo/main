## Reading the example data

bp.dat <- read.csv("bloodpressure.csv")

## Summarizing the data

class(bp.dat)

names(bp.dat)

head(bp.dat)

dim(bp.dat)

# ?head

summary(bp.dat)

apply(bp.dat[,6:7], 2, median)

tapply(bp.dat$High,bp.dat$AP,mean)

tapply(bp.dat$Low,bp.dat$AP,mean)

tapply(bp.dat$High,list(bp.dat$AP,bp.dat$Day),mean)

tapply(bp.dat$Low,list(bp.dat$AP,bp.dat$Day),mean)

## Plot

plot(bp.dat[,6:8])

hist(bp.dat$Pulse,xlab="Pulse",main="Daily Pulse Record")

boxplot(bp.dat$High~bp.dat$AP)

par(mfrow=c(2,2),las=1)

plot(bp.dat$Day,bp.dat$High,xlab="Day",ylab="High",col=bp.dat$AP,pch=16)

legend(2,133,c("AM","PM"),col=1:2,pch=16)

abline(h=135, col=4, lty=2)

plot(bp.dat$Day,bp.dat$Low,xlab="Day",ylab="Low",col=bp.dat$AP,pch=16)

abline(h=85, col=4, lty=2)

plot(bp.dat$Day,bp.dat$Pulse,xlab="Day",ylab="Pulse",col=bp.dat$AP,pch=16)

abline(h=60, col=4, lty=2)
abline(h=100, col=4, lty=2)

plot(bp.dat$Day,bp.dat$High-bp.dat$Low,xlab="Day",ylab="High-Low",col=bp.dat$AP,pch=16)

dev.off()

# library(lattice)
# xyplot(High~Day|AP:Iteration,data=bp.dat)

## Regression model

# simple

modelH.1 <- lm(High~Day,data=bp.dat)

summary(modelH.1)

confint(modelH.1,level=0.9)  # 

par(mfrow=c(1,1),las=1)

plot(bp.dat$Day, bp.dat$High, xlab="Day", ylab="High", pch=16, col="dark red", cex=1.2)

abline(modelH.1,col="steelblue4",lwd=2,lty=2)

dev.off()

# goodness of fit

rs <-  resid(modelH.1)

par(mfrow=c(1,2),mar=c(5,5,5,5),las=1)

plot(predict(modelH.1), rs, xlab="Predicted", ylab="Residual", pch=16, col="blue", cex=1.2)

abline(h=0.0,col="red",lty=2,lwd=2)

qqnorm(rs, ylab="Residual",col="blue",cex=1.2,pch=16)
qqline(rs,col="red",lty=2,lwd=2)

dev.off()

# multiple regression

bp.dat.am <- subset(bp.dat, AP=="AM")
bp.dat.pm <- subset(bp.dat, AP=="PM")

par(mfrow=c(2,2),las=1)

plot(bp.dat.am$Day, bp.dat.am$High, xlab="Day", ylab="High", main="AM", pch=as.character(bp.dat.am$Iteration), col=bp.dat.am$Iteration, cex=1.2)

plot(bp.dat.am$Day, bp.dat.am$Low, xlab="Day", ylab="Low", main="AM", pch=as.character(bp.dat.am$Iteration), col=bp.dat.am$Iteration, cex=1.2)

plot(bp.dat.pm$Day, bp.dat.pm$High, xlab="Day", ylab="High", main="PM", pch=as.character(bp.dat.pm$Iteration), col=bp.dat.pm$Iteration, cex=1.2)

plot(bp.dat.pm$Day, bp.dat.pm$Low, xlab="Day", ylab="Low", main="PM", pch=as.character(bp.dat.pm$Iteration), col=bp.dat.pm$Iteration, cex=1.2)

dev.off()

modelH.2 <- lm(High~Day+AP,data=bp.dat)

summary(modelH.2)

modelH.3 <- lm(High~Day+AP+factor(Iteration),data=bp.dat)

summary(modelH.3)

modelH.Poly <- lm(High~Day+I(Day^2)+I(Day^3),data=bp.dat)

summary(modelH.Poly)

modelH.IA <- lm(High~Day*AP, data=bp.dat)

# modelH.IA <- lm(High~Day+AP+Day:AP, data=bp.dat)

summary(modelH.IA)

par(mfrow=c(1,1),las=1)

plot(bp.dat$Day, bp.dat$High, xlab="Day", ylab="High", pch=16, col=bp.dat$AP, cex=1.2)

abline(a=modelH.IA$coef[1],b=modelH.IA$coef[2], col="blue",lwd=2,lty=2)

abline(a=modelH.IA$coef[1]+modelH.IA$coef[3],b=modelH.IA$coef[2]+modelH.IA$coef[4], col="pink",lwd=2,lty=2)

dev.off()

# model selection

bp.dat$Iteration <- factor(bp.dat$Iteration)

AIC(modelH.1, modelH.2, modelH.3)

modelH.f <- update(modelH.3, ~.^2)

library(MASS)

stepAIC(modelH.f)

aic.c <- function(x){
  n <- attr(logLik(x),"nobs")
  k <- attr(logLik(x),"df")

  return(AIC(x) + 2*k*(k+1)/(n-k-1))
}

sapply(list(modelH.1,modelH.2,modelH.3),aic.c)

library(MuMIn)

dredge(modelH.f,rank="AIC")
dredge(modelH.f,rank="AICc")

model.avg(dredge(modelH.f),subset = weight > 0.05)

modelH.b <- lm(High~Day+Iteration,data=bp.dat)

modelL.f <- lm(Low~Day+AP+Iteration,data=bp.dat)
modelL.f <- update(modelL.f,~.^2)

stepAIC(modelL.f)
dredge(modelL.f)

modelL.b <- lm(Low~Day+AP+Iteration,data=bp.dat)

par(mfrow=c(1,1),las=1)

plot(bp.dat$Day, bp.dat$High, xlab="Day", ylab="High", pch=as.character(bp.dat$Iteration), col=bp.dat$AP, cex=1.2)

abline(a=modelH.b$coef[1],b=modelH.b$coef[2], col="blue",lwd=2,lty=2)

abline(a=modelH.b$coef[1]+modelH.b$coef[3],b=modelH.b$coef[2], col="blue",lwd=2,lty=2)

abline(a=modelH.b$coef[1]+modelH.b$coef[4],b=modelH.b$coef[2], col="blue",lwd=2,lty=2)

dev.off()

# prediction

predict(modelH.b, newdata=list(Day=30,Iteration=factor(1)))

pred.int <- function(x,alpha=0.9) predict(modelH.b, newdata=list(Day=x, Iteration=factor(1)), interval="prediction", level=alpha)

ans.to.Q <- function(x,obj=125,index=1,alpha=0.9) pred.int(x,alpha)[index]-obj

uniroot(ans.to.Q,c(10,50))

uniroot(ans.to.Q,c(10,1000),alpha=0.9,index=3)

# delta.method

pred.H <- predict(modelH.b, newdata=list(Day=30,Iteration=factor(1)),se=TRUE)

pred.L <- predict(modelL.b, newdata=list(Day=30,Iteration=factor(1), AP=factor("AM"),levels=c("AM","PM")),se=TRUE)

ci.HoL <- function(predH, predL, alpha=0.95){

  level <- 1-(1-alpha)/2

  HoL <- predH$fit/predL$fit

  CV.H <- predH$se.fit/predH$fit
  CV.L <- predL$se.fit/predL$fit

  se.HoL <- sqrt(HoL^2*(CV.H^2+CV.L^2))

  out <- c(HoL, se.HoL, HoL+c(-1,1)*qnorm(level)*se.HoL)

  names(out) <- c("est","se","ci.lo","ci.up")

  return(out)
}

ci.HoL(pred.H, pred.L)

# Others

plot(modelH.1)

influence.measures(modelH.1)

lm(High~Day-1, data=bp.dat)

anova(modelH.f)

lm(High~offset(Low)+Day,data=bp.dat)

##�@GLM

# binomial (logistic) model

modelB.f <- glm(High-Low > 40 ~ Day+AP, family=binomial, data=bp.dat)
modelB.f <- update(modelB.f, ~.^2)

modelB.b <- stepAIC(modelB.f)

# Poisson model

modelP.f <- glm(Pulse~Day+AP+Iteration,family=poisson,data=bp.dat)
modelP.f <- update(modelP.f, ~.^2)

modelP.b <- stepAIC(modelP.f)

# Overdispersion

require(MASS)

modelNB.b <- glm.nb(Pulse~Day*AP,data=bp.dat)

AIC(modelP.b, modelNB.b)

library(lme4)

n <- nrow(bp.dat)

bp.dat$High.dif <- c(NA,bp.dat$High[2:n]-bp.dat$High[1:(n-1)])
bp.dat$Low.dif <- c(NA,bp.dat$Low[2:n]-bp.dat$Low[1:(n-1)])

modelHD.f <- glm((bp.dat$High.dif > 0)~Day*AP, family=binomial,data=bp.dat)
modelLD.f <- glm((bp.dat$Low.dif > 0)~Day*AP, family=binomial,data=bp.dat)

modelHD.b <- stepAIC(modelHD.f)
modelLD.b <- stepAIC(modelLD.f)

dredge(modelHD.f,rank="AIC")
dredge(modelLD.f,rank="AIC")

# Random effect simulation

library(lme4)

set.seed(1)

a <- 150
b <- -0.7

sigma <- 10

n <- 20

it <- 3

eta <- 30

a.r <- rnorm(n, 0, eta)

x <- rep(1:n,each=it)

index <- rep(1:n,each=it)

N <- n*it

y1 <- rnorm(N, a+b*x, sigma)

y2 <- rnorm(N, a+a.r[index]+b*x, sigma)

model1.1 <- lm(y1~x)
model1.2 <- lmer(y1~x+(1|x),REML=F)

AIC(model1.1,model1.2)

model2.1 <- lm(y2~x)
model2.2 <- lmer(y2~x+(1|x),REML=F)

AIC(model2.1,model2.2)

par(mfrow=c(2,2),las=1)
plot(x,y1,xlab="Day",ylab="BP",main="w/o random effect", pch=16, cex=1.2, col="blue")

abline(a=model1.1$coef[1], b=model1.1$coef[2], col="red", lty=2, lwd=2)

plot(x,y2,xlab="Day",ylab="BP",main="w/ random effect", pch=16, cex=1.2, col="blue")

abline(a=fixef(model2.2)[1], b=fixef(model2.2)[2], col="red", lty=2, lwd=2)

plot(fitted(model1.1), resid(model1.1), xlab="Predicted", ylab="Residual", main="w/o random effect", pch=16, cex=1.2, col="green")

abline(h=0, col="orange", lty=2, lwd=2)

plot(fitted(model2.1), resid(model2.1), xlab="Predicted", ylab="Residual", main="w/ random effect", pch=16, cex=1.2, col="green")

abline(h=0, col="orange", lty=2, lwd=2)

dev.off()

par(mfrow=c(2,1),las=1)

plot(fitted(model2.1), resid(model2.1), xlab="Predicted", ylab="Residual", main="w/o random effect model", pch=16, cex=1.2, col="pink")

abline(h=0, col="orange", lty=2, lwd=2)

plot(fitted(model2.2), resid(model2.2), xlab="Predicted", ylab="Residual", main="w/ random effect model", pch=16, cex=1.2, col="purple")

abline(h=0, col="orange", lty=2, lwd=2)

dev.off()

# Random effects

require(lme4)

n <- nrow(bp.dat)

ID <- rep(NA,n)

ID[1] <- 1

for (i in 2:n){
  if (bp.dat$Day[i]==bp.dat$Day[i-1] & bp.dat$AP[i]==bp.dat$AP[i-1]) ID[i] <- ID[i-1]
  else ID[i] <- ID[i-1]+1
}

modelH.RE <- lmer(High~Day+Iteration+(1|ID),data=bp.dat,REML=FALSE)

AIC(modelH.b, modelH.RE)

# GLMM

modelB.RE <- glmer((High - Low > 40) ~ Day+(1|ID),family=binomial,data=bp.dat)

# �x�N�g����A

plot(bp.dat$Low, bp.dat$High,xlab="Low",ylab="High",pch=16,col="blue3")

library(VGAM)

modelV1.1 <- vglm(cbind(High, Low)~Day+AP+Iteration,data=bp.dat,binormal(eq.mean=FALSE),maxit=1000)

modelV1.2 <- vglm(cbind(High, Low)~Day+AP,data=bp.dat,binormal(eq.mean=FALSE),maxit=1000)

modelV1.3 <- vglm(cbind(High, Low)~Day+Iteration,data=bp.dat,binormal(eq.mean=FALSE),maxit=1000)

modelV1.4 <- vglm(cbind(High, Low)~AP+Iteration,data=bp.dat,binormal(eq.mean=FALSE),maxit=1000)

modelV1.5 <- vglm(cbind(High, Low)~Day,data=bp.dat,binormal(eq.mean=FALSE),maxit=1000)

modelV1.6 <- vglm(cbind(High, Low)~AP,data=bp.dat,binormal(eq.mean=FALSE),maxit=1000)

modelV1.7 <- vglm(cbind(High, Low)~Iteration,data=bp.dat,binormal(eq.mean=FALSE),maxit=1000)

modelV1.8 <- vglm(cbind(High, Low)~1,data=bp.dat,binormal(eq.mean=FALSE),maxit=1000)

sapply(list(modelV1.1,modelV1.2,modelV1.3,modelV1.4,modelV1.5,modelV1.6,modelV1.7,modelV1.8),AIC)


modelV1.1.1 <- vglm(cbind(High, Low)~Day+AP+Iteration,data=bp.dat,binormal(eq.mean=~Day-1),maxit=1000)

modelV1.1.2 <- vglm(cbind(High, Low)~Day+AP+Iteration,data=bp.dat,binormal(eq.mean=~AP-1),maxit=1000)

modelV1.1.3 <- vglm(cbind(High, Low)~Day+AP+Iteration,data=bp.dat,binormal(eq.mean=~Iteration-1),maxit=1000)

modelV1.1.4 <- vglm(cbind(High, Low)~Day+AP+Iteration,data=bp.dat,binormal(eq.mean=~Day+AP-1),maxit=1000)

modelV1.1.5 <- vglm(cbind(High, Low)~Day+AP+Iteration,data=bp.dat,binormal(eq.mean=~Day+Iteration-1),maxit=1000)

modelV1.1.6 <- vglm(cbind(High, Low)~Day+AP+Iteration,data=bp.dat,binormal(eq.mean=~AP+Iteration-1),maxit=1000)

modelV1.1.7 <- vglm(cbind(High, Low)~Day+AP+Iteration,data=bp.dat,binormal(eq.mean=~Day+AP+Iteration-1),maxit=1000)

sapply(list(modelV1.1,modelV1.1.1,modelV1.1.2,modelV1.1.3,modelV1.1.4,modelV1.1.5,modelV1.1.6,modelV1.1.7),AIC)

modelV.b <- modelV1.1.4

# GAM

library(mgcv)

modelH.GAM <- gam(High~s(Day)+AP+Iteration, data=bp.dat)

dredge(modelH.GAM,rank="AIC")

modelH.GAM.b <- gam(High~s(Day)+Iteration, data=bp.dat)

plot(modelH.GAM.b)

new1 <- list(Day=c(30,60,90), Iteration=rep(factor(1),3))

predict(modelH.b,newdata=new1,se=TRUE)
predict(modelH.GAM.b,newdata=new1,se=TRUE)
