MSY.EST2 <-
function(res,
  SR.rel="HS",
  waa=NULL,
  maa=NULL,
  M=NULL,
  waa.year=NULL, 
  maa.year=NULL,
  M.year=NULL,
  rps.year = NULL, 
  transformation="log",
  g1 = 0.01,
  sel=NULL,
  max.age = Inf,
  sigma=0.5,
  n.gi=30,
  bcor=TRUE,
  min.F=0,
  max.F=2,
  int.F=0.01,
  F0=0.1,
  est=TRUE,
  k = 0,
  statmod=FALSE,
  p.init=NULL){
  #

  argname <- ls()
  arglist <- lapply(argname,function(x) eval(parse(text=x)))
  names(arglist) <- argname
  
  caa <- res$input$dat$caa
  naa <- res$naa
  ssb <- res$ssb
  ny <- ncol(naa)
  years <- dimnames(naa)[[2]]
  ages <- dimnames(caa)[[1]]
  
  if(is.null(waa.year)) waa.year <- rev(years)[1]
  if(is.null(maa.year)) maa.year <- rev(years)[1]
  if(is.null(M.year)) M.year <- rev(years)[1]
  if(is.null(rps.year)) rps.year <- as.numeric(colnames(res$naa))

  if(is.null(waa))  waa <- apply(as.matrix(as.data.frame(res$input$dat$waa)[as.character(waa.year)]),1,mean)
  if(is.null(M))  M <- apply(as.matrix(as.data.frame(res$input$dat$M)[as.character(M.year)]),1,mean)
  if(is.null(maa))  maa <- apply(as.matrix(as.data.frame(res$input$dat$maa)[as.character(maa.year)]),1,mean)
    
  if(is.null(sel)){
    sel <- sweep(res$faa,2,apply(res$faa,2,max),FUN="/")
  }
   
  na <- nrow(caa)

  Pope <- res$input$Pope

  nY <- length(rps.year)
  
    SSB <- as.numeric(colSums(ssb)[1:(nY-k)])
    R <- as.numeric(res$naa[1,][(1+k):nY])
 
   min.SSB <- min(SSB)
   max.SSB <- max(SSB)
   
    SR.func <- function(p) {
      a <- exp(p[1])
      if (SR.rel=="HS"){
        b <- (max.SSB-min.SSB)/(1+exp(-p[2]))+min.SSB
        pred.R <- ifelse(SSB >= b, a*b, a*SSB)
        if (transformation=="id") obj <- sum((R-pred.R)^2)
        if (transformation=="log")  obj <- sum((log(R)-log(pred.R))^2)
      }
      if (SR.rel=="MR"){
        b <- (max.SSB-min.SSB)/(1+exp(-p[2]))+min.SSB
        pred.R <- a*(SSB+sqrt(b^2+g1^2/4)-sqrt((SSB-b)^2+g1^2/4))
        if (transformation=="id") obj <- sum((R-pred.R)^2)
        if (transformation=="log")  obj <- sum((log(R)-log(pred.R))^2)
      }
      if (SR.rel=="BH"){
        b <- exp(p[2])
        pred.R <- a*SSB/(1+b*SSB)
        if (transformation=="id") obj <- sum((R-pred.R)^2)
        if (transformation=="log")  obj <- sum((log(R)-log(pred.R))^2)
      }
      if (SR.rel=="RI"){
        b <- exp(p[2])
        pred.R <- a*SSB*exp(-b*SSB)
        if (transformation=="id") obj <- sum((R-pred.R)^2)
        if (transformation=="log")  obj <- sum((log(R)-log(pred.R))^2)
      }
      obj
    }
    
    if(is.null(p.init)){
      if (SR.rel=="HS" | SR.rel=="MR") p.init <- c(log(median(R/SSB)),logit((median(SSB)-min.SSB)/(max.SSB-min.SSB)))
      if (SR.rel=="BH" | SR.rel=="RI") p.init <- c(log(median(R/SSB)),-log(max.SSB))
    }
        
    out <- nlm(SR.func,p.init)
    p <- out$estimate
    a <- exp(p[1])
    
    if (SR.rel=="HS" | SR.rel=="MR") b <- (max.SSB-min.SSB)/(1+exp(-p[2]))+min.SSB
    if (SR.rel=="BH" | SR.rel=="RI") b <- exp(p[2])
        
    out$sr.par <- c(a,b)
    
    #
   
     if (statmod){
       require(statmod)
       gi <- gauss.quad(n.gi,kind="hermite") 
       x.gi <- gi$nodes
       wex2.gi <- gi$weights*exp(x.gi^2)
    } else{
     x.gi <- c(
     -6.8633453, -6.1382792, -5.5331472, -4.9889190, -4.4830554, -4.0039086,
     -3.5444439, -3.0999705, -2.6671321, -2.2433915, -1.8267411, -1.4155278,
     -1.0083383, -0.6039211, -0.2011286,  0.2011286,  0.6039211,  1.0083383,
      1.4155278,  1.8267411,  2.2433915,  2.6671321,  3.0999705,  3.5444439,
      4.0039086,  4.4830554,  4.9889190,  5.5331472,  6.1382792,  6.8633453)

      wex2.gi <- c(
      0.8342475,0.6490980,0.5694027,0.5225257,0.4910580,0.4683748,0.4513210,
      0.4381770,0.4279181,0.4198950,0.4136794,0.4089816,0.4056051,0.4034198,
      0.4023461,0.4023461,0.4034198,0.4056051,0.4089816,0.4136794,0.4198950,
      0.4279181,0.4381770,0.4513210,0.4683748,0.4910580,0.5225257,0.5694027,
      0.6490980,0.8342475) 
    }
    
    Fr <- seq(min.F,max.F,by=int.F)
      
    if (SR.rel=="HS" | SR.rel=="MR"){
      R0 <- a*b
               
      YPR.f0 <- function(Fr,x,sel){
        N.HS <- R0*calc.rel.abund(t(sel),Fr,na,M,waa,maa,max.age=max.age,Pope=Pope)$rel.abund
        SSB.HS <- sum(N.HS*waa*maa)*exp(sigma*x-bcor*sigma^2/2)
        ifelse(SSB.HS < b,0,R0*exp(sigma*x-bcor*sigma^2/2)*sum(calc.rel.abund(t(sel),Fr,na,M,waa,maa,max.age=max.age,Pope=Pope)$ypr))
      }
      
      YPR.f <- function(Fr,x) mean(apply(sel,2,YPR.f0,Fr=Fr,x=x))
      
      if (est){
        YPR <- sapply(Fr, function(Fr) sum(YPR.f(Fr,x.gi)*dnorm(x.gi)*wex2.gi))
       
        Fmsy <- Fr[which.max(YPR)]
        MSY <- max(YPR,na.rm=TRUE)
      } else{
        YPR <- sum(YPR.f(F0,x.gi)*dnorm(x.gi)*wex2.gi)
        Fmsy <- F0
        MSY <- YPR      
      }
      
     
      Abund0 <- function(Fr,sel)  R0*calc.rel.abund(t(sel),Fr,na,M,waa,maa,max.age=max.age,Pope=Pope)$rel.abund
      Abund <- function(Fr)  rowMeans(apply(sel,2,Abund0,Fr=Fr))

      Nmsy <-  Abund(Fmsy)
      Bmsy <- Nmsy*waa
      SSBmsy <- Bmsy*maa
      
      N0 <- Abund(0)
      B0 <- N0*waa
      SSB0 <- B0*maa 
    }    
    
    if (SR.rel=="BH"){    
       YPR.f0 <- function(Fr,x,sel){
        R <- (a*sum(calc.rel.abund(t(sel),Fr,na,M,waa,maa,max.age=max.age,Pope=Pope)$rel.abund*waa*maa)-1)/(b*sum(calc.rel.abund(t(sel),Fr,na,M,waa,maa,max.age=max.age,Pope=Pope)$rel.abund*waa*maa))
        R <- ifelse(R >=0, R, 0)
        N.BH <- R*calc.rel.abund(t(sel),Fr,na,M,waa,maa,max.age=max.age,Pope=Pope)$rel.abund
        SSB.BH <- sum(N.BH*waa*maa)*exp(sigma*x-bcor*sigma^2/2)
        a*SSB.BH/(1+b*SSB.BH)*sum(calc.rel.abund(t(sel),Fr,na,M,waa,maa,max.age=max.age,Pope=Pope)$ypr)
      }
            
      YPR.f <- function(Fr,x) mean(apply(sel,2,YPR.f0,Fr=Fr,x=x))

      YPR <- sapply(Fr, function(Fr) sum(YPR.f(Fr,x.gi)*dnorm(x.gi)*wex2.gi))
      
      Fmsy <- Fr[which.max(YPR)]
      MSY <- max(YPR,na.rm=TRUE)
      
      Abund0 <- function(Fr,sel)  {
        R <- (a*sum(calc.rel.abund(t(sel),Fr,na,M,waa,maa,max.age=max.age,Pope=Pope)$rel.abund*waa*maa)-1)/(b*sum(calc.rel.abund(t(sel),Fr,na,M,waa,maa,max.age=max.age,Pope=Pope)$rel.abund*waa*maa))
        R*calc.rel.abund(t(sel),Fr,na,M,waa,maa,max.age=max.age,Pope=Pope)$rel.abund
      }
      Abund <- function(Fr)  rowMeans(apply(sel,2,Abund0,Fr=Fr))

      Nmsy <-  Abund(Fmsy)
      Bmsy <- Nmsy*waa
      SSBmsy <- Bmsy*maa
      
      N0 <- Abund(0)
      B0 <- N0*waa
      SSB0 <- B0*maa 
    }       

    if (SR.rel=="RI"){    
       YPR.f0 <- function(Fr,x,sel){
        R <- log(a*sum(calc.rel.abund(t(sel),Fr,na,M,waa,maa,max.age=max.age,Pope=Pope)$rel.abund*waa*maa))/(b*sum(calc.rel.abund(t(sel),Fr,na,M,waa,maa,max.age=max.age,Pope=Pope)$rel.abund*waa*maa))
        R <- ifelse(R >=0, R, 0)
        N.RI <- R*calc.rel.abund(t(sel),Fr,na,M,waa,maa,max.age=max.age,Pope=Pope)$rel.abund
        SSB.RI <- sum(N.RI*waa*maa)*exp(sigma*x-bcor*sigma^2/2)
        a*SSB.RI*exp(-b*SSB.RI)*sum(calc.rel.abund(t(sel),Fr,na,M,waa,maa,max.age=max.age,Pope=Pope)$ypr)
      }
            
      YPR.f <- function(Fr,x) mean(apply(sel,2,YPR.f0,Fr=Fr,x=x))

      YPR <- sapply(Fr, function(Fr) sum(YPR.f(Fr,x.gi)*dnorm(x.gi)*wex2.gi))
      
      Fmsy <- Fr[which.max(YPR)]
      MSY <- max(YPR,na.rm=TRUE)
      
      Abund0 <- function(Fr,sel)  {
        R <- log(a*sum(calc.rel.abund(t(sel),Fr,na,M,waa,maa,max.age=max.age,Pope=Pope)$rel.abund*waa*maa))/(b*sum(calc.rel.abund(t(sel),Fr,na,M,waa,maa,max.age=max.age,Pope=Pope)$rel.abund*waa*maa))
        R*calc.rel.abund(t(sel),Fr,na,M,waa,maa,max.age=max.age,Pope=Pope)$rel.abund
      }
      Abund <- function(Fr)  rowMeans(apply(sel,2,Abund0,Fr=Fr))

      Nmsy <-  Abund(Fmsy)
      Bmsy <- Nmsy*waa
      SSBmsy <- Bmsy*maa
      
      N0 <- Abund(0)
      B0 <- N0*waa
      SSB0 <- B0*maa 
    }       

   out$sigma <- sigma
   out$bcor <- bcor
   
   msy <- c(MSY, Fmsy)
   names(msy) <- c("MSY","Fmsy")
   
   out$rps.year <- rps.year
   out$nY <- nY
   
   out$MSY <- msy
   out$Nmsy <- Nmsy
   out$Bmsy <- Bmsy
   out$SSBmsy <- SSBmsy

  out$N0 <- N0
  out$B0 <- B0
  out$SSB0 <- SSB0
  
  return(out)
}
