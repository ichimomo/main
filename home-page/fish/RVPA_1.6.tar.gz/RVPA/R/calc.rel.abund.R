calc.rel.abund <-
function(sel,Fr,na,M,waa,maa,max.age=Inf,Pope=TRUE){
  rel.abund <- rep(NA, na)
  rel.abund[1] <- 1
  for (i in 2:(na-1)) {
    rel.abund[i] <- rel.abund[i-1]*exp(-M[i-1]-sel[i-1]*Fr)
  }
  rel.abund[na] <- rel.abund[na-1]*exp(-M[na-1]-sel[na-1]*Fr)*(1-exp(-(max.age-(na-2))*(M[na]+sel[na]*Fr)))/(1-exp(-M[na]-sel[na]*Fr))

  if(isTRUE(Pope)){
    ypr1 <- rel.abund*waa[1:na]*(1-exp(-sel[1:na]*Fr))*exp(-M[1:na]/2)
  }
  else{
  # use Baranov catch equation
    ypr1 <- rel.abund*(1-exp(-sel[1:na]*Fr-M[1:na]))*sel[1:na]*Fr/
                                      (sel[1:na]*Fr+M[1:na])*waa[1:na]
#    ypr1 <- numeric()
#    for(i in 1:(na-1)){
#      ypr1[i] <- (rel.abund[i]-rel.abund[i+1])*Fr*sel[i]/(Fr*sel[i]+M[i])
#    }
#    ypr1[na] <- (rel.abund[na])*Fr*sel[i]/(Fr*sel[i]+M[i])
#    ypr1 <- ypr1*waa
  }
  spr <- rel.abund*waa[1:na]*maa[1:na] # waa��maa��NA������Δn�}�C���V�̂��߂ɁA!is.na(waa)��ǉ�
  return(list(rel.abund=rel.abund,ypr=ypr1,spr=spr))
}
