doss3 <-
function(how.many=1,ss3.arg=""){
  for(i in 1:how.many){
    if(.Platform$OS.type=="unix"){
      system("cp ss3.par SS3.PAR")        
      system(paste("ss3 ",ss3.arg))
    }
    else{
      shell(paste("ss3.exe ",ss3.arg))
    }
  }
}

