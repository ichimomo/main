toshi <-
function(x){
  sprintf("%03.0f", x)
}

