is.ss3 <-
function(repfile){
  a <- read.csv(repfile,nrow=1,colClasses="character",header=F)
  tmp <- as.numeric(substr(a[1,1],5,8))>3
  if(is.na(tmp)) tmp <- FALSE
  tmp
}

