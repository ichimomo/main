set.mypar <-
function(){
  par(mgp=c(1.8,0.3,0),tck=0.03,ps=11,cex.main=1,font.main=1,adj=0.5,oma=c(0,0,0,0))
}

