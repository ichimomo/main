getNAA.ss2 <-
function(repfile,cl=NULL,tb=NULL,target.line=NULL){
  read.char <- "NUMBERS_AT_AGE" #
  line.tmp <- ifelse(is.ss3(repfile),0,1)
  if(is.null(cl)){
    cl <- count.fields(repfile,blank.lines.skip=FALSE)
  }  
  if(is.null(target.line)){
    if(is.null(tb)){
      tb <- read.table(repfile,fill=T,col.names=paste("V",1:max(cl),sep=""),as.is=T,
                       blank.lines.skip=FALSE)
    }
    name.label <- find.and.read.table2(read.char,skipline=line.tmp,gyou=1,
                      table.property=cl,tb=tb,outfile=repfile,h=FALSE,is.ss2=TRUE,colClasses="character")  
    naa <- find.and.read.table2(read.char,skipline=line.tmp+1,gyou=NULL,
                      table.property=cl,tb=tb,outfile=repfile,h=FALSE,is.ss2=TRUE,comment.char="")
  }
  else{
    name.label <- find.and.read.table(read.char,skipline=line.tmp,startpoint=target.line-10,gyou=1,
                                      table.property=cl,
                                      outfile=repfile,h=FALSE,is.ss2=TRUE,colClasses="character")  
    naa <- find.and.read.table(read.char,skipline=line.tmp+1,startpoint=name.label[[2]]-10,gyou=NULL,
                               table.property=cl,comment.char="",
                               outfile=repfile,h=FALSE,is.ss2=TRUE)
  }
#  naa[[1]] <- lapply(naa[[1]],as.character)
#  naa[[1]] <- lapply(naa[[1]],as.numeric)
  naa[[1]] <- as.data.frame(naa[[1]])
#  res[[1]][res[[1]]=="+1.#IND"] <- Inf
#  res[[1]] <- as.data.frame(res[[1]])
  colnames(naa[[1]]) <- as.character(name.label[[1]])
  if(more.ss3.11(repfile)){
    colnames(naa[[1]])[7] <- "Year"
    colnames(naa[[1]])[11] <- "Per"    
  }
  else{
    if(is.ss3(repfile)){
      colnames(naa[[1]])[7] <- "Year"
      colnames(naa[[1]])[10] <- "Per"
    }}
  if(more.ss3.11(repfile)) naa[[1]] <- naa[[1]][naa[[1]]$"Beg/Mid"=="B",]
  naa
}

