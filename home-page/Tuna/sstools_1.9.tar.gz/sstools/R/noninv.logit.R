noninv.logit <-
function (ip) 
{
    log(ip/(1 - ip))
}
