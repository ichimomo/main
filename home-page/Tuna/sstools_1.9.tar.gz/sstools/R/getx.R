getx <-
function (list) 
{
    list$x
}
