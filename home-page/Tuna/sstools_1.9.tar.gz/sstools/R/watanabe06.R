watanabe06 <-
function (len) 
{
    1.2e-05 * (len)^3.08
}
