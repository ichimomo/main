MP.CESqt3 <-
function(cl,args.mp=list(
                           # $BI,$:I,MW$J%*%W%7%g%s(B
                           Fcur1=NULL, # CurrentF=$B5y6HJLG/NpJL(BF$B$N%Y%/%H%k!#4IM}A0(B <- do.projection$B$G$O!"(BFyear1 $B$rM?$($l$P(Bdo.projection$B$G7W;;$7$F$/$l$k(B
                           Fcur2=NULL, # CurrentF=$B5y6HJLG/NpJL(BF$B$N%Y%/%H%k!#4IM}8e(B <- do.projection$B$G$O!"(BFyear2 $B$rM?$($l$P(Bdo.projection$B$G7W;;$7$F$/$l$k(B
                           start.regulation=2011, # $B4IM}$r<B;\$9$kG/(B
                           # $B4pK\E*$K$O!"(Bmake.partcacharg$B$NJV$jCM$rMQ$$$k(B
                           CES.multi=1,
                           # $BI,$:$7$bI,MW$G$J$$%*%W%7%g%s(B
                           CES.plus=0,
                           CES.multi.year=NULL,# 1000$BG/0J>e$N>-MhM=B,$r$9$k$H$3$N%*%W%7%g%s$G%(%i!<=P$k$N$GCm0U(B
                           # $BFbIt$G7W;;$5$l$k$b$N!#MbG/$K$b0z$-EO$5$l$k0z?t(B
                           CES0=NULL,
                           # $B5y3MNL$N%-%c%C%T%s%0$N%*%W%7%g%s(B 
                           catch.capping=NULL
                           # or list(reg.fleet=c(2,3), #regulation$B$r$9$k5y6H(B
                           #         upper.catch=c(3000,1000),# $B5y3MNL$N>e8B(B
                           #         reset.timing=c(2,1)) # $B5y3MNL$N>e8B$r%j%;%C%H$9$k%?%$%_%s%0(B
                           #up.limit=NULL, #$B;H$o$l$F$$$J$$(B                          
                           )){
  qt.label <- c(0,0.25,0.5,0.75)
  current.season <- get.qtcode(cl$timing[1],qt.label=qt.label)
  year.label <- as.numeric(rownames(cl$faat))
  
  #---- $BF~NO$5$l$F$$$J$$%Q%i%a!<%?$NF~NO(B
  if(is.null(args.mp$CES.plus)) args.mp$CES.plus <- 0
  if(is.null(args.mp$CES.multi.year)) args.mp$CES.multi.year <- rep(1,1000)
#  if(is.null(args.mp$gm))   args.mp$gm <- FALSE

  #----- tmp.CES$B$N:n@.(B
  tmp.CES <- args.mp$CES0 * args.mp$CES.multi * args.mp$CES.multi.year[floor(as.numeric(cl$timing[1])-cl$initial.year)+1]+ args.mp$CES.plus  

  #------------------- catch$B$N%-%c%C%T%s%0$r9T$&>l9g(B
  #-------------------
  args.mp$new.partial.ratio <- NULL # $B$3$N%*%W%7%g%s$G;H$&(Bnew.partial.ratio$B$OKh2s99?7$9$k(B       
  if(!is.null(args.mp$catch.capping) &&
     as.numeric(cl$timing[1])>=args.mp$start.regulation){
    #------ $BJQ?t$N=i4|2=(B
    reg.fleet <- args.mp$catch.capping$reg.fleet
    upper.catch <- args.mp$catch.capping$upper.catch # $B5y3MNL>e8BNL!JG/7W!K(B
    reset.timing <- args.mp$catch.capping$reset.timing
    
    # remaining catch$B$N@_Dj$,$5$l$F$$$J$$$^$?$O%9%?!<%HG/$N>l9g!J7W;;$N0lHV:G=i!K(B
    if(as.numeric(cl$timing[1])==args.mp$start.regulation){
      args.mp$remaining.catch <- upper.catch
    }

    #$B:#$N;MH>4|$,(Breset.timing$B$J$i!";D$j$N5y3MNL$r%j%;%C%H$9$k(B    
    for(i in 1:length(reg.fleet)){
      if(sum(current.season==reset.timing[[i]])>0){ # $BJ#?t$N;MH>4|$,(Breset.timing$B$H$J$C$F$b$$$$(B
        args.mp$remaining.catch[i] <- upper.catch[i]
      }
    }

    #-------------- $BM=A[$5$l$k5y3MNL(B(part.catch)$B$r7W;;$9$k(B
    #---- $BJ#?t5y6H$G(Bupper limit$B$r9M$($k>l9g$O!"N>J}$N(BF$B$rF0$+$7$FN>J}$N5y3MNL$r$T$C$?$j9g$o$;$i$l$k(B
    #---- $B$H$O8B$i$J$$!#$=$N>l9g$r9M$(!"$"$kDxEY$N;D:9$r;D$7$F7W;;$r%9%H%C%W$5$;$k$h$&$K$9$k!)(B
    #---- $B",$^$@<BAu$O$7$F$$$J$$(B
    #    part.F <- sweep(cl$partial.catch$ratio,1,tmp.CES,FUN="*")
    #    part.catch <- get.partialcatch(cl=cl,fleet.multi=rep(1,cl$nfleet),part.F=part.F)$part.catch

    # $B:#G/$N5y3MJ,$HMhG/5y3M$G$-$k;D$j$N5y3MNL(B
    part.catch <- get.partialcatch(cl=cl,fleet.multi=rep(1,cl$nfleet),part.F=args.mp$Fcur2)$part.catch    
    remaining.catch.next <- args.mp$remaining.catch-part.catch[reg.fleet]

    # $BMhG/5y3M$G$-$k;D$j$,Ii$@$C$?$i(B ->$B$=$N5y6H$N(Bupper limit$B$r@_Dj(B
    adjust.F <- rep(1,cl$nfleet)
    if(sum(remaining.catch.next<0)>0){
      this.season.reg.fleet <- reg.fleet[which(remaining.catch.next<0)]
      this.season.upper <- args.mp$remaining.catch[which(remaining.catch.next<0)]
      # $B5y3MNL$,%<%m$N>l9g(B
      if(sum(this.season.upper==0)){
        adjust.F[this.season.reg.fleet[this.season.upper==0]] <- 0
      }
    }

    # part.catch$B$H;D$j$N5y3MNL$r99?7(B
    part.catch <- get.partialcatch(cl=cl,fleet.multi=adjust.F,part.F=args.mp$Fcur2)$part.catch    
    remaining.catch.next <- args.mp$remaining.catch-part.catch[reg.fleet]
    if(sum(remaining.catch.next<0)>0){    
      this.season.reg.fleet <- reg.fleet[which(remaining.catch.next<0)]
      this.season.upper <- args.mp$remaining.catch[which(remaining.catch.next<0)]
      # $B;D$j$N5y3MNL$,CfEYH>C<$@$C$?>l9g(B
      if(sum(this.season.upper>0)){        
        tmp.F <- sweep(args.mp$Fcur2,2,adjust.F,FUN="*")
        res <- optim(rep(1,length(this.season.reg.fleet[this.season.upper>0])),# $B=i4|CM(B      
                     cal.diffpartcatch,# $B:G>.2=$9$Y$-4X?t(B
                     part.F=tmp.F,cl=cl,reg.fleet=this.season.reg.fleet[this.season.upper>0],
                     upper.catch=this.season.upper[this.season.upper>0]#upper.catch
                     )
        adjust.F[this.season.reg.fleet[this.season.upper>0]] <- res$par  # $B3F5y6H$X$N(Bmultipler
        #        cat(cl$timing," ",round(adjust.F,2),"\n")
      }}

    #   part.catch2 <- get.partialcatch(cl=cl,fleet.multi=adjust.F,part.F=args.mp$Fcur2) # $B<B:]$N5y3MNL!J$?$7$+$aMQ!K(B
    args.mp$new.partial.ratio <- sweep(args.mp$Fcur2,2,adjust.F,FUN="*")      
    #    part.catch3 <- get.partialcatch(cl=cl,part.F=args.mp$new.partial.ratio) # $B<B:]$N5y3MNL!J$?$7$+$aMQ!K(B
    #    cat("|",round(part.catch3[[1]])[this.season.reg.fleet]," vs ",round(this.season.upper),"\n")      

    #      cat(" Actual:",round(part.catch3[[1]][this.season.reg.fleet]),"\n")
    tmp.CES <- apply(args.mp$new.partial.ratio,1,sum)

    # $BMhG/$N;D$j$N5y3MNL$N99?7(B
    args.mp$remaining.catch <- ifelse(remaining.catch.next>0,remaining.catch.next,0)
  }

  #----- $B$3$3$^$GMh$F!"$^$@(Bnew.partial.ratio$B$,(BNULL$B$@$C$?$i!"!"!#(B
  #----- Fcur1$B$H(BFcur2$B$r@_Dj$7$D$D!"(Bupper limit$B$O@_Dj$7$F$$$J$$>l9g!"$H$$$&$3$H(B
  if(is.null(args.mp$new.partial.ratio)){
    f.factor <- args.mp$CES.multi * args.mp$CES.multi.year[floor(as.numeric(cl$timing[1])-cl$initial.year)+1]+ args.mp$CES.plus
    if(as.numeric(cl$timing[1])<args.mp$start.regulation){# $B4IM}A0(B  
      args.mp$CES0 <- apply(args.mp$Fcur1,1,sum)
      args.mp$new.partial.ratio <- args.mp$Fcur1 * f.factor
    }
    else{ # $B4IM}8e(B
      args.mp$CES0 <- apply(args.mp$Fcur2,1,sum)
      args.mp$new.partial.ratio <- args.mp$Fcur2 * f.factor
    }
    tmp.CES <- args.mp$CES0 * f.factor
  }
  
  list(res=tmp.CES,args.mp=args.mp)
}

