cal.diffpartcatch2 <-
function(par,cl,part.F,reg.fleet,upper.catch){
#  tmp <- rep(1,cl$nfleet)
#  tmp[reg.fleet] <- pars
  tmp2 <- sum(get.partialcatch2(cl=cl,fleet.multi=par,part.F=part.F)$part.catch[reg.fleet])
  return((upper.catch-tmp2)^2)
}

