get.qtcode <-
function(qt.digit,qt.label=c(0,0.25,0.5,0.75)){
  which(as.numeric(qt.digit)-floor(as.numeric(qt.digit)) == qt.label)
}

