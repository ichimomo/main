do.projection.ss <-
function(mcore=1, # $BJBNs2=$9$k$+!)(Bmcore>1$B$GJBNs2=(B
                             bootfiles,faafiles=NULL,config.list,
                             # $B0J2<$O%"%I%[%C%/$J%*%W%7%g%s!#%G%U%)%k%H$N$^$^$G(BOK
                             minus2kgSPS=FALSE,faa.multiplier=NULL,by.fleet.CES=NULL){
  #$BF~NO$7$F$b8z$+$J$$!J>e$N@_Dj$G>e=q$-$5$l$k!K$N$O!"(B
  #  partial.catch, HSlimit, Rec.fun, args.R
  if(0){  # $B$=$N$[$+$N@_Dj(B
    #--- $B4IM}J}:v$N@_Dj(B
    #--- $B$=$NB>(B
    P.catch=c(2004,2006) # $B%*%U$N>l9g(B
    # P.catch=c(2004,2006),  # P.catch$B$,%*%s$N>l9g!#(BpredictN$B$N(Bpartial.catch$B%*%W%7%g%s$K(B
    # make.partcatcharg$B$N=PNO7k2L$,F~$k(B
    by.fleet.CES=NULL
    #---- $B%"%I%[%C%/$J%*%W%7%g%s(B                    
    minus2kgSPS=FALSE
    target.fleet=1
    limit.bin=46
  # 2kg$B0J2<$N5y3M$r%<%m$H$7$?$H$-$N%*%W%7%g%s72(B
    #---- $B%"%I%[%C%/$J%*%W%7%g%s#2(B                    
    #                             qt2regulation=FALSE, # SPS$B$N(B10$B$+$i(B12$B7n$N(BF$B$r%<%m$H$9$k(B==>$B$b$&;H$($J$$(B
    faa.multiplier=NULL # faa.array$B$K>h$8$k(Barray
    # $B;CDjE*$K(Bbluefin.predictN$B$N0z?t$+$i$b$C$F$-$?(B
    ex.ssb=0
    qt=4
  #-------------------                           
  }

  #--- $B=*N;>r7o$N@_Dj(B   -----
  bsres <- list()  
  exit.function <- function(){
    save(bsres,file="bsres_rescued.R")
    if(mcore>2) sfStop()
  }
  on.exit(exit.function())
    
  #--- bootfiles$B$OI,?\!"(Bfaafiles$B$b$G$-$l$P;XDj$9$k(B
  bootfiles <- bootfiles[config.list$boot[1]:config.list$boot[2]]
  if(!is.null(faafiles)){
    faafiles <- faafiles[config.list$boot[1]:config.list$boot[2]]
  }
  nboot <- ifelse(!is.null(faafiles),length(faafiles),length(bootfiles))

  #--- configN.list$B$N@0Hw(B
  config.tmp <- config.list
  configN.list <- list()
  for(i in 1:nboot){
    repfile <- bootfiles[i]    
    # faafiles$B$,$"$C$?>l9g!"(Brepfile$B$O!"(Bfaafiles$B%*%V%8%'%/%HFb$N$b$N$rMQ$$$k(B
    # $B%Q%9$NLdBj$,$"$k$,!"!"!#(B
    if(!is.null(faafiles)){
      a <- load(faafiles[i])
      faa.tmp <- get(a)      
    }
    else{
      faa.tmp <- calFAA.ss2(repfile)
    }

    #------------ Ad hoc $B$J%*%W%7%g%s$K$h$k(Bfaa.tmp$B$N=q$-49$((B
    #------------ minus2kgSPS$B$N%*%W%7%g%s$,%*%s$N>l9g(B
    #------------$B!JFCDj$N5y6H$K$*$$$F!"(Blimit.bin$B0J2<$X$N5y3M05$,$J$/$J$C$?$i!)(B
    if(minus2kgSPS==TRUE){
      target.term <- c(2002,2004.75)
      a <- calTotcatch.select(repfile,target.fleet=target.fleet,target.term=target.term)

      bins <- as.numeric(rownames(a$target.res[[1]]))
      impact.50cm <- array(0,dim=c(length(a$target.res),21,nboot))
      numbers.50cm <- array(0,dim=c(length(a$target.res),21,nboot))
      for(j in 1:length(a$target.res)){
        impact.50cm[j,,i] <- apply(a$target.res[[j]][bins<limit.bin,],2,sum)/apply(a$target.res[[j]],2,sum)
        # 50cm$B0J2<$NG/NpJL5y3MHx?t$N3d9g(B
        numbers.50cm[j,,i] <- apply(a$target.res[[j]][bins<limit.bin,],2,sum)
        # 50cm$B0J2<$NG/NpJL5y3MHx?t(B  
      }
      caa.tmp <- a$datas$caa
      years <- as.numeric(dimnames(caa.tmp$caa.array)[[1]])
      tmp <- years >= target.term[1] & years <= target.term[2]
      caa.tmp$caa.array[tmp,,2] <- caa.tmp$caa.array[tmp,,target.fleet]-numbers.50cm[,,i] # SPS$B$N(Bcaa$B$r:o8:!*(B
      a$datas$caa$caa.array  <- caa.tmp$caa.array
      faa.tmp <- calFAA.ss2(repfile,age.limit=c(1,2,3,4,5,rep(6,16)),namae=c(0,1,2,3,4,"5-20"),
                             datas=a$datas)
    }
    
    if(!is.null(by.fleet.CES)){
      faa.tmp <- control.F.byfleet(faa.tmp,fleet.F=by.fleet.CES)
    }

    if(!is.null(faa.multiplier)){
      faa.tmp$faa.array <- faa.tmp$faa.array*faa.multiplier
      faa.tmp$faa <- apply(faa.tmp$faa.array,c(1,2),sum)
    }
    #------------------ faa.tmp$B$N=q$-49$(=*$o$j(B ---------------------
    
    # NAA,FAA$BEy$r>-MhM=B,$KF~$l$kMQ$KJQ49!J#4H>4|!K(B
    config.tmp$outdata <- b <- to.quarterbase(outdata=faa.tmp,qt=4)

    #---------- $B2CF~MQ$N%Q%i%a!<%?$N@_Dj(B ----------------------------
    # $B2CF~$,(BBeverton-Holt + logrmal error$B$N>l9g!#(Bargs.R$rec.timing$B0J30$N0z?t$O$3$3$G7W;;(B
    if(config.list$Rec.fun=="REC.beverton.ss"){
      para <- getSRpara.ss2(repfile)[[1]]
      tmpR <- config.list$args.R 
      config.tmp$args.R <- list(steepness=ifelse(is.null(tmpR$steepness),para$steepness,tmpR$steepness),
                                R0=ifelse(is.null(tmpR$R0),exp(para$logR0)*1000,tmpR$R0),
                                Rsigma=ifelse(is.null(tmpR$Rsigma),para$sigmaR,tmpR$Rsigma),
                                B0=ifelse(is.null(tmpR$B0),para$SSB0,tmpR$B0),
                                Rdev.seed=para$Rdev.seed,                                
                                recruit.qt=tmpR$recruit.qt,
                                resampled=tmpR$resampled,
                                year.lim=tmpR$year.lim)
    }

    # $B2CF~$r#2$D$N%U%'!<%:$KJ,$1$k>l9g!#;vA0$N(Bargs.R$B$N0z?t$OI,MW$J$$(B
    if(config.list$Rec.fun=="REC.twophase"){
      SRtmp <- getSPR.ss2(repfile)[[1]]
      config.tmp$args.R$ssb.threshold <- median(SRtmp$SPB)
      config.tmp$args.R$R.lowerset <- SRtmp$Recruit[config.tmp$args.R$ssb.threshold > SRtmp$SPB]
      config.tmp$args.R$R.upperset <- SRtmp$Recruit[config.tmp$args.R$ssb.threshold < SRtmp$SPB]
    }    

    # Hockey-Stick$B%*%W%7%g%s$r;H$&>l9g(B
    if(is.null(config.list$HSlimit)){
      config.tmp$HSlimit <- NULL
    }
    else{
      config.tmp$HSlimit <- config.list$HSlimit[i]
    }

    # qt3$B$N%*%W%7%g%s(B($B4IM}$N<B9TA0$H<B9T8e$N#2$D$N%U%'!<%:$r2>Dj$9$k!K>l9g!#(B
    # $B0z?t$rKh2sJQ$($kI,MW$"$k(B
    # $B$3$N>l9g!"(Bto.quarterbase$BFb$N(Bfaat$B$O;H$o$J$$(B
    if(is.element(config.list$MP,c("MP.CESqt3","MP.CESqt4","MP.CHSfleet"))){
#      if(EPO02Other04==FALSE){
      config.tmp$partial.catch <-
        make.partcatcharg(faa.res=control.F.byfleet(faa.tmp,fleet.F=config.list$args.mp$fleet.multi1),
                          yr.range=config.list$args.mp$Fyear1,gm=config.list$gm)
      config.tmp$args.mp$Fcur1 <- config.tmp$partial.catch$Fmat
      config.tmp$args.mp$Fcur2 <-
          make.partcatcharg(faa.res=control.F.byfleet(faa.tmp,fleet.F=config.list$args.mp$fleet.multi2),
                            yr.range=config.list$args.mp$Fyear2,gm=config.list$gm)$Fmat
      }
    else{
      if(config.list$MP=="MP.hybrid"){
        # $B>e=R$ND4@0$r4X?t2=$7$F!"%k!<%W$K$9$k(B
        for(kk in 1:length(config.list$args.mp)){
          config.tmp$partial.catch <-
            make.partcatcharg(faa.res=control.F.byfleet(faa.tmp,
                                fleet.F=config.list$args.mp[[kk]]$fleet.multi1),
                              yr.range=config.list$args.mp[[kk]]$Fyear1,
                              gm=config.list$gm)
          config.tmp$args.mp[[kk]]$Fcur1 <- config.tmp$partial.catch$Fmat
          config.tmp$args.mp[[kk]]$Fcur2 <- 
            make.partcatcharg(faa.res=control.F.byfleet(faa.tmp,
                                fleet.F=config.list$args.mp[[kk]]$fleet.multi1),
                              yr.range=config.list$args.mp[[kk]]$Fyear2,
                              gm=config.list$gm)$Fmat          

        }
      }
      else{
        # MP$B$,>e=R$N$J$s$G$b$J$$$H$-!#(Bpartial.catch$B$K$J$s$+$rF~$l$F$*$+$J$$$HF0$+$J$$$N$G(B
        config.tmp$partial.catch <- make.partcatcharg(faa.res=faa.tmp,yr.range=c(1990,2000),
                                                       gm=config.list$gm)
      }
    }

    # $B>-MhM=B,$N<B9T(B
#    configN.list[[i]] <- list(outdata=b,partial.catch=part.arg,
#                          HSlimit=hs.limit,MP=MP.tmp,args.mp=args.mp.tmp,
#                          Rec.fun=Rec.fun.tmp,args.R=args.R.tmp,
#                          initial.year=initial.year,pred.year=pred.year,N=N,
#                          ex.ssb=ex.ssb,qt=qt,record.NAA=record.NAA)
    

    #HSlimit=hs.limit,MP=MP.tmp,args.mp=args.mp.tmp,
    #Rec.fun=Rec.fun.tmp,args.R=args.R.tmp,
    #                      initial.year=initial.year,pred.year=pred.year,N=N,
    #ex.ssb=ex.ssb,qt=qt,record.NAA=record.NAA)
    configN.list[[i]] <- config.tmp
  }
  if(mcore==1){
    z <- lapply(configN.list,bluefin.predictN)
  }
  else{
    library(snowfall)
    sfInit(parallel=TRUE,cpus=mcore)
    sfLibrary(sstools)
    sfLibrary(ssfuture)    
    z <- sfLapply(configN.list,bluefin.predictN)
    sfStop()        
  }

  if(minus2kgSPS==TRUE){
    save(numbers.50cm,file="numbers.50cm.R")
    save(impact.50cm,file="impact.50cm.R")
  }

  bsres <- add.dim(z)
  bsres$Totcatch <- bsres$"Total catch"
  bsres$"Total catch" <- NULL

  cat("end of calc\n")
  invisible(bsres)
}

