make.configlist <-
function(){
  return(list(MP="",Rec.fun=""))
}

