MP.CHSfleet <-
function(cl,args.mp=list(
                           # $BI,$:I,MW$J%*%W%7%g%s(B
                             CHS.qt=NULL, # qt $B$ND9$5$N%Y%/%H%k(B
                             Fyear1=NULL,
                             Fyear2=NULL,
                             Fcur1=NULL, # CurrentF=$B5y6HJLG/NpJL(BF$B$N(Bselectivity$B!#4IM}A0(B <- Fyear1 $B$rM?$($l$P(Bdo.projection$B$G7W;;$7$F$/$l$k(B
                             Fcur2=NULL, # CurrentF=$B5y6HJLG/NpJL(BF$B$N(Bselectivity$B!#4IM}8e(B <- Fyear2 $B$rM?$($l$P(Bdo.projection$B$G7W;;$7$F$/$l$k(B
                             start.regulation=2011, # $B4IM}$r<B;\$9$kG/(B
                           # $B4pK\E*$K$O!"(Bmake.partcacharg$B$NJV$jCM$rMQ$$$k(B
                           CES.multi=1,
                           # $BI,$:$7$bI,MW$G$J$$%*%W%7%g%s(B
                           CES.plus=0,
                           CES.multi.year=NULL,# 1000$BG/0J>e$N>-MhM=B,$r$9$k$H$3$N%*%W%7%g%s$G%(%i!<=P$k$N$GCm0U(B
                           # $BFbIt$G7W;;$5$l$k$b$N!#MbG/$K$b0z$-EO$5$l$k0z?t(B
                           CES0=NULL,
                           )){
  qt.label <- c(0,0.25,0.5,0.75)
  current.season <- get.qtcode(cl$timing[1],qt.label=qt.label)
  
  if(is.null(args.mp$CES.plus)){
    args.mp$CES.plus <- 0
  }

  if(is.null(args.mp$CES.multi.year)){
    args.mp$CES.multi.year <- rep(1,1000)
  }  

#  if(is.null(args.mp$gm)){
#    args.mp$gm <- FALSE
#  }

  year.label <- as.numeric(rownames(cl$faat))

#  args.mp$CES0 <- args.mp$CES.qt[current.season,]
  # $B4IM}A0(B
  # $B$I$s$J>l9g$G$b(B new.partial.ratio$B$KCM$rF~$l$k!#!a(B> $BK\BN$N(Bpartial.catch$B$O>e=q$-$5$l$k(B
  if(as.numeric(cl$timing[1])<args.mp$start.regulation){
    args.mp$CES0 <- apply(args.mp$Fcur1,1,sum)
    args.mp$new.partial.ratio <- args.mp$Fcur1        
  }
  else{ # $B4IM}8e(B
    args.mp$CES0 <- apply(args.mp$Fcur2,1,sum)
    args.mp$new.partial.ratio <- args.mp$Fcur2    
  }
  tmp.CES <- args.mp$CES0 * args.mp$CES.multi * args.mp$CES.multi.year[floor(as.numeric(cl$timing[1])-cl$initial.year)+1]
    + args.mp$CES.plus  

  #------------------- catch$B$N@_Dj(B
  args.mp$new.partial.ratio <- NULL # $B$3$N%*%W%7%g%s$G;H$&(Bnew.partial.ratio$B$OKh2s99?7$9$k(B       
  if(as.numeric(cl$timing[1])>=args.mp$start.regulation){

    reg.fleet <- 1:cl$nfleet
    upper.catch <- args.mp$CHS.qt[current.season]
    
    adjust.F <- 1#rep(1,cl$nfleet)
    tmp.F <- args.mp$Fcur2*adjust.F
    res <- optimize(interval=c(0,1000),# $B=i4|CM(B      
                    f=cal.diffpartcatch2,# $B:G>.2=$9$Y$-4X?t(B
                    part.F=tmp.F,cl=cl,reg.fleet=reg.fleet,
                    upper.catch=upper.catch#upper.catch
                    )
    adjust.F <- res$minimum  # $B3F5y6H$X$N(Bmultipler
#        cat(cl$timing," ",round(adjust.F,2),"\n")

#      part.catch2 <- get.partialcatch(cl=cl,fleet.multi=adjust.F,part.F=args.mp$Fcur2) # $B<B:]$N5y3MNL!J$?$7$+$aMQ!K(B
    args.mp$new.partial.ratio <- args.mp$Fcur2*adjust.F
#    part.catch3 <- get.partialcatch(cl=cl,part.F=args.mp$new.partial.ratio) # $B<B:]$N5y3MNL!J$?$7$+$aMQ!K(B
#    cat("|",round(part.catch3[[1]])[this.season.reg.fleet]," vs ",round(this.season.upper),"\n")      

    #      cat(" Actual:",round(part.catch3[[1]][this.season.reg.fleet]),"\n")
    tmp.CES <- apply(args.mp$new.partial.ratio,1,sum)

    # $BMhG/$N;D$j$N5y3MNL$N99?7(B
#    args.mp$remaining.catch <- ifelse(remaining.catch.next>0,remaining.catch.next,0)
#    cat(cl$timing[1]," ",args.mp$remaining.catch,"\n")
  }
  
  list(res=tmp.CES,args.mp=args.mp)
}

