add.dim <-
function(list.tmp){
  res.list <- list()
  nboot <- length(list.tmp)
  for(i in 1:length(list.tmp[[1]])){
    new.dim <- c(dim(list.tmp[[1]][[i]]),nboot)
    res.array <- array(0,dim=new.dim)
    if(length(new.dim)==4){
      for(j in 1:nboot) res.array[,,,j] <- list.tmp[[j]][[i]]
#      browser()      
      dim(res.array) <- c(dim(res.array)[1],dim(res.array)[2],dim(res.array)[3]*dim(res.array)[4])
      dimnames(res.array)[1:2] <- dimnames(list.tmp[[j]][[i]])[1:2]

    }
    else{
      if(length(new.dim)==3){
        for(j in 1:nboot) res.array[,,j] <- list.tmp[[j]][[i]]
        res.array <- aperm(res.array,c(2,1,3))
        dim(res.array) <- c(dim(res.array)[1],dim(res.array)[2]*dim(res.array)[3])
        res.array <- t(res.array)
        dimnames(res.array)[[2]] <- dimnames(list.tmp[[j]][[i]])[[2]]
      }
      else{
        if(length(new.dim)==2){
          for(j in 1:nboot) res.array[,j] <- list.tmp[[j]][[i]]                  
        }}}
    res.list[[i]] <- res.array
  }
  names(res.list) <- names(list.tmp[[1]])
#  browser()
  return(res.list)
}

