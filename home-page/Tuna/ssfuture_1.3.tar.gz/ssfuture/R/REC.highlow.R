REC.highlow <-
function(cl,args.R=list(year.lim=NULL,
                             qt=1,recruit.qt=1,                
                             high.year=NULL,high.limit=Inf,high.time=0,
                             )){
  # high.year$B$G@_Dj$7$?G/$K!"(Bhigh.limit$BK|Hx0J>e$NBn1[G/5i72$,5/$3$k$H9M$($k(B
  years <- as.numeric(rownames(cl$outdata$Numbers))
  rec <- cl$outdata$Numbers[years>=args.R$year.lim[1] &
                            years<=args.R$year.lim[2],colnames(cl$outdata$Numbers)==0]  
  rec <- rec[rec!=0]
  
  rec.low <- rec[rec<args.R$high.limit*10000]
  res <- rep(0,nrow(cl$naat.pred))
  nyear <- rownames(cl$naat.pred)

  # $BBn1[G/5i$,H/@8$9$k4|4V$N2CF~(B
  if(args.R$high.time!=0){
    rec.high <- rec[rec>args.R$high.limit*10000]
    hy <- args.R$high.year
    dim(hy) <- c(2,args.R$high.time)

    for(i in 1:args.R$high.time){
      res[nyear>=hy[1,i] & nyear<=hy[2,i]][ceiling(runif(1,min=0,max=(hy[2,i]-hy[1,i]+1)))] <-
        rec.high[ceiling(runif(1,min=0,max=length(rec.high)))]
    }
  }

  # $B$=$l0J30$NG/$N2CF~(B
#  res[res==0] <- rec.low[ceiling(runif(sum(res==0),min=0,max=length(rec.low)))]
  res[res==0] <- rec.low[sample.year.normal <- sample(1:length(rec.low),sum(res==0),replace=TRUE)]
  

  # ss2$B$KBP1~$9$kItJ,!#2CF~$O(Brecruit.qt$B$K$*$3$k$H$9$k(B
  if(args.R$qt>2){
    tmp <- 1:length(res)
    res[tmp%%4!=args.R$recruit.qt] <- 0
#    res[!((tmp%%args.R$qt) %in% args.R$recruit.qt)] <- 0
  }
    
  res <- list(res=res,args.R=args.R)  # $BBh0lG/L\$b?dDjCM$r;H$&(B
  
}

