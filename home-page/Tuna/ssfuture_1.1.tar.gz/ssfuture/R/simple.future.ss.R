simple.future.ss <-
function(res,target,probs=c(0.1,0.5,0.9)){
  for(i in 1:length(res)){
    x <- t(apply(res[[i]][target][[1]],2,quantile,probs=probs))    
    if(i==1){
      matplot(x,type="l",col=c("gray",1,"gray"),lty=c(2,1,2),lwd=1)
      res.out <- array(0,dim=c(length(res),nrow(x),length(probs)))
      dimnames(res.out) <- list(names(res),rownames(x),probs)
    }
    else{
      matpoints(x,type="l",col=c("gray",1,"gray"),lty=c(2,1,2),lwd=1)
    }
    res.out[i,,] <- x          
  }
  invisible(res.out)
}

