MP.CHS <-
function(cl,
                   args.mp=list(CHS0=NULL,CHS.year=NULL,CHS.plus=0,
                     select.year=NULL,select.chs=NULL)){

#  if(cl$c.code==TRUE) dyn.load("/home/momoko/Tuna/packages/SA2R/src/slvbaranov.so")     
  if(is.null(args.mp$CHS0)){
    if(is.null(args.mp$CHS.year)){
      cat("There is neither 'CHS0' nor 'CHS.year'!")
    }
    else{
      tc <- cl$tc
      args.mp$CHS0 <- mean(tc[rownames(tc)>=args.mp$CHS.year[1] & rownames(tc)<=args.mp$CHS.year[2]])
      #cat("1 ")
    }
  }

  if(is.null(args.mp$select.chs)){
    if(is.null(args.mp$select.year)){
      cat("There is neither 'select.chs' nor 'select.year'!\n")
    }
    else{
    args.mp$select.chs <- apply(cl$faat[rownames(cl$faat)>=args.mp$select.year[1] &
                                    rownames(cl$faat)<=args.mp$select.year[2],1:cl$n.age],2,mean)
    #cat("2 "    )
  }
  }
  args.mp$select.chs <- args.mp$select.chs / max(args.mp$select.chs)

  if(args.mp$CHS0!=0){
    multiplier.F <- optimize(branov.eq,c(0,10),tol=0.0000001,n.age=cl$n.age,
                             naat.pred.vec=cl$naat.pred,
                             select.para=args.mp$select.chs,waa=cl$waa,nmaa=cl$nmaa,
                             CHS=args.mp$CHS0+args.mp$CHS.plus)$minimum
#    multiplier.F <- ifelse(cl$c.code==FALSE,
#                           optimize(branov.eq,c(0,10),tol=0.0000001,n.age=cl$n.age,
#                                    naat.pred.vec=cl$naat.pred,
#                                    select.para=args.mp$select.chs,waa=cl$waa,nmaa=cl$nmaa,
#                                    CHS=args.mp$CHS0+args.mp$CHS.plus)$minimum,
#                           ifelse((b <- solve.baranov(cl$n.age,cl$naat.pred,args.mp$select.chs,
#                                                      cl$waa,cl$nmaa,args.mp$CHS0+args.mp$CHS.plus))
#                                  ==-100,10,b)
#                           )
  }
  else{
    multiplier.F <- 0
  }
  list(res=multiplier.F*args.mp$select.chs,args.mp=args.mp)
}

