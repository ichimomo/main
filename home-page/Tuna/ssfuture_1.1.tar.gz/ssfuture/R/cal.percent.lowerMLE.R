cal.percent.lowerMLE <-
function(res.list,orgfile,
                          limit.year=c(2010,2026),limit.ssb=NULL,
                          sp.season=4){  # $BFCDj$N%P%$%*%^%9$r;XDj6h4V$G0l2s$G$b2<2s$k3NN((B
  limit.ssb.tmp <- limit.ssb
  a <- getSPR.ss(orgfile)[[1]]  
  for(i in 1:length(limit.ssb)){
    if(limit.ssb[i]=="ATHL"){
      limit.ssb.tmp[i] <- mean(sort(a$SPB)[1:10])
    }
    else{if(as.nc(limit.ssb[i])<1){
      limit.ssb.tmp[i] <- quantile(a$SPB,probs=as.nc(limit.ssb[i]))
    }}
  }
  limit.ssb <- as.numeric(limit.ssb.tmp)
#  browser()

  pers <- matrix(0,length(res.list),length(limit.ssb))
  dimnames(pers) <- list(names(res.list),limit.ssb)
  years <- as.numeric(colnames(res.list[[1]]$SSB))
  if(!is.null(sp.season)){
    season.tmp <- qtback(years)==sp.season
  }
  else{
    season.tmp <- TRUE
  }
  tmp <- years>=(limit.year[1])&years<=(limit.year[2])&season.tmp
#  browser()
  for(j in 1:length(limit.ssb)){
    for(i in 1:length(res.list)){
      res <- res.list[[i]]
      if(sum(tmp)>1){
        pers[i,j] <- sum(apply(res$SSB[,tmp]<limit.ssb[j],1,sum)>0)/
          nrow(res$SSB)*100
      }
      else{
        pers[i,j] <- sum(res$SSB[,tmp]<limit.ssb[j])/
          nrow(res$SSB)*100        
      }
  }}
  return(pers)
}

