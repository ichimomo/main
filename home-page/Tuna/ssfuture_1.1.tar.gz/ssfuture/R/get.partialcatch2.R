get.partialcatch2 <-
function(cl,fleet.multi=1,part.F=NULL){
    part.catch <- numeric()
    ctmp <- 0
    if(is.null(part.F)){
      part.F <- cl$partial.catch$ratio
    }

    new.Fmat <- part.F*fleet.multi
    for(nf in 1:cl$nfleet){
      tmp <- branov.eq.pre4(naat.pred.vec=cl$naat.pred,
#                            waa=cl$partial.catch$waaf,nmaa=cl$nmaa,
                            waa=cl$partial.catch$waaf.mtrx,nmaa=cl$nmaa,                            
                            partial.F=new.Fmat,fleet=nf)
      part.catch[nf] <-  sum(tmp,na.rm=TRUE)
    }
  return(list(part.catch=part.catch,new.Fmat=new.Fmat))
}

