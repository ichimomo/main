Fssb.chart <-
function(res.fssb,bootres,f.var2,orgfile,col.var=1,add=TRUE,limit.year=c(2008,2033),
                       point.threshold=FALSE,sp.season=2,is.plot=TRUE,limit.ssb=(1:10)/10,
                       lower.probs=c(0.05,0.1,0.5)# $B$=$l$>$l$N3NN($N$H$3$m$G(BF$B$,$$$/$D$K$J$k$N$+!)(B
                       ){

  a <- getSPR.ss(orgfile)[[1]]
#  quantiles.tmp <- seq(from=0,to=0.7,length=dim(a)[[1]]*2) # SSB$B$N(Bquantile

  # $B3F(Bthreshold$B$K$*$1$k(B %_lower_ssb$B$r7W;;(B
  if(point.threshold==FALSE){
    # $B3F%V!<%H%9%H%i%C%W$N?dDjCM$r;H$&>l9g(B
    
    x1 <- cal.percent.lowerboot(res.fssb,bootres,limit.year=limit.year,limit.percentile=limit.ssb,sp.season=sp.season)
#    x2 <- cal.percent.lowerboot(res.fssb,bootres,limit.year=c(2029.75,2030.75),limit.ssb=quantiles.tmp,sp.season=sp.season)
  }
  else{
    # $BE@?dDj$r;H$&>l9g(B
    SPRs <- getSPR.ss(orgfile)[[1]]
    x1 <- list(cal.percent.lowerMLE(res.fssb,limit.year=limit.year,orgfile=orgfile,
                             limit.ssb=limit.ssb,sp.season=sp.season))
#    x2 <- list(cal.percent.lowerMLE(res.Fssb46,limit.year=c(2030.75,2030.75),limit.ssb=quantile(SPRs$SPB,probs=quantiles.tmp),sp.season=4))
  }

  # $B%9%W%i%$%s$G!"L\I8$H$9$k(Bpercent$B$N$H$3$m$G(BF$B$,$$$/$D$K$J$k$N$+$rM=B,(B
  pers.mat1 <- pers.mat2 <- matrix(0,length(lower.probs),length(limit.ssb))
  dimnames(pers.mat1) <- dimnames(pers.mat2) <- list(lower.probs,limit.ssb)
#  plot(c(0,1.5),c(0,1),type="n")
  for(i in 1:length(limit.ssb)){
    pers.mat1[,i] <- predict.Fssb(f.var2,x1[[1]][,i],target.pers=lower.probs,add=F,is.plot=T)
#    browser()
#    pers.mat2[,i] <- predict.Fssb(f.var2,x2[[1]][,i],target.pers=lower.probs,add=T)
  }

  if(is.plot==TRUE){
    set.mypar()
    par(mfrow=c(2,1),mar=c(3,3,2,1),ps=11)
    if(add==F){
      matplot(limit.ssb,t(pers.mat1[c(1,3),]),lty=1:2,col=col.var,type="l",xlab="SSB threshold",ylab="F multipler",xlim=c(0,0.7),ylim=c(0.3,1.2))
    }
    else{
      matpoints(limit.ssb,t(pers.mat1[c(1,3),]),lty=1:2,col=col.var,type="l",xlab="SSB threshold",ylab="F multipler",xlim=c(0,0.7),ylim=c(0.3,1.2))
    }
#    points(limit.ssb,t(pers.mat2[3,]),lty=1:2,col=1,type="l",lwd=2)
    abline(h=c(1,0.83),v=c(0.48,0,0.25,0.1),col="gray")
  }
  
#  return(list(pers.mat1,pers.mat2)) # pes.mat1 <- limit.year$B$N4|4V(B  # pers.mat2 <- equilibrium$B$K6a$$4|4V$N$_(B
  return(list(pers.mat1,x1)) # pes.mat1 <- limit.year$B$N4|4V(B  # pers.mat2 <- equilibrium$B$K6a$$4|4V$N$_(B  
}

