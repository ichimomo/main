update.number2 <-
function(n1,n0,a.max,m,f,age.name){
  init.age <- min(which(as.numeric(age.name)>0))
  for(i in init.age:(a.max-1)){
    n1[i] <- n0[i-1]*exp(-f[i-1]-m[i-1])
  }
  n1[a.max] <- n0[a.max-1]*exp(-f[a.max-1]-m[a.max-1]) + n0[a.max]*exp(-f[a.max]-m[a.max])
#  browser()
  n1
}

