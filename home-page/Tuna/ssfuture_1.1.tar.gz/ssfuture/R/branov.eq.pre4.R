branov.eq.pre4 <-
function(naat.pred.vec,waa,nmaa,partial.F,fleet){
  totalF <- apply(partial.F,1,sum)
  tc <- (naat.pred.vec*waa[,fleet]*partial.F[,fleet])/
			(totalF+nmaa)*(1-exp(-totalF-nmaa))
		
  tc/1000
}

