calc.aav <-
function(mat,x1,x2){
  mean(apply(abs(mat[,(x1+1):(x2)] - mat[,(x1):(x2-1)]),2,sum)/n)
}

