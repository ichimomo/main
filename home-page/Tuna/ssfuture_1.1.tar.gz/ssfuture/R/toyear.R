toyear <-
function(mat,numbers=T){
  tmp <- matslice(mat,4)
  year <- as.numeric(rownames(tmp))
  tmp <- tmp[year-floor(year)==0,]
  tmp
}

