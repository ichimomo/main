pictex.template <-
function(picfile="test.tex",tempfile="template.tex"){
  cat("\\documentclass[a4paper]{jarticle}
\\usepackage{pictex}
\\usepackage{graphics}
\\begin{document}
\\input{",
      file=tempfile)
  cat(picfile,file=tempfile,append=T)
  cat("}
\\end{document}",file=tempfile,append=T)
}

