replace.sd.offset <-
function(ctrfile,repfile,newctl="control_new.ctl",def.sd=0.2,replace.sd=c(T,T,T,T,T,T),vnumber=1){
  b <-  getCPUE.ss2(repfile,target.line=11,vnumber=vnumber)[[3]]
  
  # $BCm!*!*(Bcontrol$B%U%!%$%k$NCV$-49$($O!"(Bctrl$B%U%!%$%k$N9T?t$r8e$m$+$i%+%&%s%H$7$F(B
  # $B9T$C$F$$$k$N$G!"(B"variance adjustment factors"$B$N5-=R0J9_$N%U%!%$%k$K$O!"(B
  # $B%3%a%s%H%"%&%H0J30$NM>7W$J2~9T$rF~$l$J$$$h$&$K$7$F$/$@$5$$(B
  cl <- count.fields(ctrfile,comment="#",blank.lines.skip=T)
  a <- read.table(ctrfile,col.names=1:max(cl),fill=T)

  nline <- ifelse(vnumber<2,20,22)
#  a[nrow(a)-nline,1:length(def.sd)] <- b[,4]-def.sd
  a[nrow(a)-nline,1:length(def.sd)] <- b$r.m.s.e-def.sd  

  write.table(a,file=newctl,na="",row.names=F,col.names=F,quote=FALSE)

  return(b$r.m.s.e)
}

