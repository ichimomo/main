plotFAA.ss <-
function(faa,col.var=1:100,lty.var=rep(1,100),lwd.var=rep(1,100),
                       ptype=rep("b",100),nline=-1,fleet.name=NA,
                       repfile.legend=NULL){
  nage <- dim(faa[[1]]$faa.array)[[2]]
  setncol(nage)

  #---------- legend -----
  nplot()
  if(is.null(repfile.legend)) repfile.legend <- sapply(faa,function(x) x[[8]])
  legend("topright",legend=repfile.legend,col=col.var,lty=lty.var,lwd=lwd.var,ncol=2)

  #---------- PLOT1 (by age)
  years <- as.numeric(rownames(faa[[1]]$faa))
  for(i in 1:dim(faa[[1]]$faa)[[2]]){
    faa.mat <- sapply(faa,function(x) x$faa[,i])
    matplot(unique(floor(years)),rowtapply(faa.mat),ylab="",xlab="",
            col=col.var,lty=lty.var,lwd=lwd.var,type="l")
    title(paste("Age",dimnames(faa[[1]]$faa.array)[[2]][i]))
    if(i%%10==9)  mtext(side=3,line=0.5,adj=0.1,"@ F at age by year (compare multi files)",outer=T)    
  }
}

