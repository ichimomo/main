as.nc <-
function(x){as.numeric(as.character(x))}

