convert.biommat <-
function(biom.mat,n=20){
  biom.tmp <- biom.mat[,(1:ncol(biom.mat))%%4==0]
  biom.tmp2 <- matrix(0,nrow(biom.tmp)*n,ncol(biom.tmp))
  s <- 1
  for(i in 1:nrow(biom.tmp)){
    for(j in 1:n){
      biom.tmp2[s,] <- as.numeric(biom.tmp[i,])
      s <- s+1
    }
  }
  return(biom.tmp2)
}

