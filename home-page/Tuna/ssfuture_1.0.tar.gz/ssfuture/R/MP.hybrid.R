MP.hybrid <-
function(cl,args.mp){
     year.list <- lapply(args.mp, function(x) x$years)
#    browser()
    year.tmp <- floor(as.numeric(cl$timing[1]))
     tmp2 <- sapply(lapply(year.list,function(xx) xx%in%year.tmp),sum)
     tmp2 <- which(tmp2==1)[1]
     MP.obj <- get(args.mp[[tmp2]]$MP)
     tmp.res <- MP.obj(cl,args.mp=args.mp[[tmp2]])
     tmp.res$args.mp <- args.mp
     return(tmp.res)
}

