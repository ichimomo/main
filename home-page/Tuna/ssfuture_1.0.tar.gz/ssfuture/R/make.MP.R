make.MP <-
function(condition.list,MP,args.mp){
  #cat(MP," ")
  MP.obj <- get(MP)
  MP.obj(condition.list,args.mp=args.mp)
}

