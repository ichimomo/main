cal.diffpartcatch <-
function(pars,cl,part.F,reg.fleet,upper.catch){
  tmp <- rep(1,cl$nfleet)
  tmp[reg.fleet] <- pars
  tmp2 <- get.partialcatch(cl=cl,fleet.multi=tmp,part.F=part.F)$part.catch[reg.fleet]
  return(sum((upper.catch-tmp2)^2))
}

