replace.F <-
function(faa){
  faa2 <- faa
  yrs <- floor(as.numeric(dimnames(faa$faa.array)[[1]]))
  tmp <- yrs>=2004 & yrs<=2006
  tmp2 <- yrs>=2002 & yrs<=2004
  faa2$faa.array[tmp,,8] <- faa$faa.array[tmp2,,8]  # <- $B$3$N(Bfaa$B$O!">-MhM=B,$G;H$C$F$$$k$b$N$H0lCW!)(B
  faa2$faa <- apply(faa2$faa.array,c(1,2),sum)
  return(faa2)
}

