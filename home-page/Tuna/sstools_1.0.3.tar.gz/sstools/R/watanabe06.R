watanabe06 <-
function(L){
  8.7 * 10^{-5} * L^{2.67}
}

