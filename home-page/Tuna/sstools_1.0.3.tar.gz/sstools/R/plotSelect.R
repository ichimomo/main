plotSelect <-
function(selects,multiplot=FALSE,len.or.age="Length",ptype="l",col.var=1,lty.var=1,lwd.var=1,nline=1){
  # Only for allplot.ss2
  if(multiplot) len.rep <- length(selects)
  nfleet <- ncol(selects[[1]])
  setncol(nfleet)
  #  par(mfcol=c(ceiling(nfleet/2),2),ps=16,mar=c(4,4,1,1))
  # if the selectivity is competely same as the one plotted just before, the selectivity will not be plotted
  # This decision is done only in multiplot[[1]]
  old.selects <- 0
  title.tmp <- strsplit(colnames(selects[[1]]),"-")
  s <- 0
  ss <- numeric()
  for(i in 1:nfleet){
    selects0 <- selects[[1]]

    if(sum(old.selects!=selects0[,i])!=0 |
       ifelse(i==1,TRUE,title.tmp[[i]][1]!=title.tmp[[i-1]][1])){

      if(i>1){
        title(paste(title.tmp[[i-1]][1],"-",title.tmp[[ss[s]]][2],"to",title.tmp[[i-1]][2],"-",title.tmp[[i-1]][3]),line=nline)
      }
      
      plot(rownames(selects0),old.selects <- selects0[,i],type=ptype,xlab="",ylab="",lwd=lwd.var[1])
      if(s %% prod(par()$mfcol)==1)
        mtext(side=3,line=0.5,adj=0.1,paste("@ ",len.or.age,"selectivity"),outer=T)            
      s <- s+1
      ss[s] <- i

      if(multiplot){
        for(j in 2:len.rep){
          points(rownames(selects[[j]]),selects[[j]][,i],type="l",col=col.var[j],lty=lty.var[j],lwd=lwd.var[j])
        }}         

#      nfile <- 1
    }}
  title(paste(title.tmp[[i-1]][1],"-",title.tmp[[ss[s]]][2],"to",title.tmp[[i-1]][2],"-",title.tmp[[i-1]][3]),line=nline)  
  if(s < prod(par()$mfcol)) mtext(side=3,line=0.5,adj=0.1,paste("@ ",len.or.age,"selectivity"),outer=T)  
}

