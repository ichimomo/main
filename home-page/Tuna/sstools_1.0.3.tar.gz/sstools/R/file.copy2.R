file.copy2 <-
function(from,to,...){
  file.copy(from=from,to=to,overwrite=T,...)
}

