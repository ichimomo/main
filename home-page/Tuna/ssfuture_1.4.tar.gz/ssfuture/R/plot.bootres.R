plot.bootres <-
function(bootres,sp.season=4,...){
  abline.tmp <- function(){
#    abline(h=quantile(b0$Spawn[b0$period=="TIME" & b0$season==sp.season],probs=c(0,0.05,0.1,0.25,0.5)),
#           col=gray(0.5),lty=2)
    abline(h=seq(from=0,to=15,by=5)*10000,col=gray(0.5),lty=2)        
  }

  biom.mat <- bootres$biom.mat
#  par(mar=c(3,3,2,0.3))
  x <- biom.mat[,tmp <- qtback(colnames(biom.mat))==sp.season & colnames(biom.mat)>=1952]
  boxplot(x,
          lwd=0.5,ylim=c(0,max(x,na.rm=T)),...)
        #  at=floor(as.numeric(colnames(biom.mat)))[tmp],add=F)
  abline.tmp()
}

