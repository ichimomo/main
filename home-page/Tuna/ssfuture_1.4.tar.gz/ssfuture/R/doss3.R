doss3 <-
function(how.many=1,ss3.arg="",use.wine=FALSE){
  for(i in 1:how.many){
    if(.Platform$OS.type=="unix" && use.wine==FALSE){
      system("cp ss3.par SS3.PAR")        
      system(paste("ss3 ",ss3.arg))
    }
    else{
      if(.Platform$OS.type=="unix" && use.wine==TRUE){
        system("cp ss3.par SS3.PAR")        
        system(paste("wine ss3.exe ",ss3.arg))        
      }
      else{
        shell(paste("ss3.exe ",ss3.arg))
    }}
  }
}

