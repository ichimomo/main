boxplot2 <-
function(x,probs=90,...){
  res <- boxplot.default(x,plot=F)
  res$stats[1,] <- sapply(x,quantile,probs=(100-probs)/200)
  res$stats[5,] <- sapply(x,quantile,probs=1-(100-probs)/200)
  bxp(res,...)
}

