REC.beverton.ss <-
function(cl,args.R=list(steepness=0.75,R0=14000000,resampled=FALSE,
                                 Rsigma=0.36,B0=60000,recruit.qt=1,Rdev.seed=NULL,year.lim=NULL)){

#  if(is.null(args.R$resampled)){
#    args.R$resampled <- F
#  }
  if(is.null(args.R$Rdev.seed2) & !is.null(args.R$year.lim)){
    years <- as.numeric(names(args.R$Rdev.seed))
    args.R$Rdev.seed2 <- args.R$Rdev.seed[years %in% args.R$year.lim[1]:args.R$year.lim[2]]
#    browser()
#    cat("call Rdev.seed2\n")
  }

  if(qtback(cl$timing[2])==args.R$recruit.qt){
#      res <- Beverton.holt.ss2(sum(cl$naat.pred*cl$waa*cl$maa/1000),
#                               coef=args.R$coef,B0=args.R$B0) *
#                    exp(rnorm(1,mean=0,sd=sqrt(args.R$R.var))-0.5*args.R$R.var)
    if(args.R$resampled==FALSE){
      res <- Beverton.holt.ss2(sum(cl$naat.pred*cl$waa*cl$maa/1000),
                               coef=c(args.R$steepness,args.R$R0),B0=args.R$B0) *
                                 exp(rnorm(1,mean=0,sd=args.R$Rsigma)-0.5*(args.R$Rsigma)^2)
    }
    else{
      res <- Beverton.holt.ss2(sum(cl$naat.pred*cl$waa*cl$maa/1000),
                               coef=c(args.R$steepness,args.R$R0),B0=args.R$B0) *
                                 exp(-0.5*(args.R$Rsigma)^2+sample(args.R$Rdev.seed2,1))
#      browser()
    }
  }
  else{
    res <- 0
  }
  list(res=res,args.R=args.R)
}

