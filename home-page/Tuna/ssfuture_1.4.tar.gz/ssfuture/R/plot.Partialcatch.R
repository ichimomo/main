plot.Partialcatch <-
function(res,by.year=T){
  nfleet <- dim(res$Partialcatch)[[3]]
  if(by.year==F){
    for(i in 1:nfleet){
      boxplot(as.data.frame(res$Partialcatch[,,i]))
    }
  }
  else{
    for(i in 1:nfleet){
      tmp <- t(rowtapply(t(res$Partialcatch[,,i])))      
      boxplot(as.data.frame(tmp))
    }    
  }
}

