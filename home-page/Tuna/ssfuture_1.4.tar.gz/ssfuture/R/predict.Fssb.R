predict.Fssb <-
function(f.var,pers,target.pers=c(0.05,0.5),add=F,is.plot=F,title.tmp=NULL){
  tmpfunc <- function(fmulti,sfun.tmp,target.per.tmp){
    (sfun.tmp(fmulti)-target.per.tmp)^2
  }

  # percentage$B$rF~$l$k$3$H$H$9$k!*(B
  x <- pers

  if(max(target.pers)>1){
    target.pers <- target.pers
  }
  else{
    target.pers <- target.pers*100
  }  

#  sfun <- splinefun(f.var,x)
  sfun <- splinefun(f.var,x,method="monoH.FC")
#  sfun <- approxfun(f.var,x)
  xx <- seq(from=min(f.var),to=max(f.var),length=1000)  

  if(is.plot){
    if(add==F){
#      browser()
      plot(f.var,x,type="p",pch=19,cex=0.8,ylim=c(0,100),xlim=c(0,2.2))
      title(title.tmp)
      abline(v=seq(from=0,to=2,by=0.1),h=seq(from=0,to=100,by=5),col="gray")
    }
    else{
      points(f.var,x,type="p",pch=19,cex=0.8)    
    }
  points(xx,sfun(xx),col="gray",type="l",lwd=2)
  }    
  
  if(!is.null(target.pers) & sum(x>0) > 1){
    F.multiplier <- character()
    for(i in 1:length(target.pers)){
      if(range(sfun(xx))[1]<=target.pers[i] && range(sfun(xx))[2]>=target.pers[i]){
#        browser()
        # $BHs>o$KHyL/$J(Blocal minimum$B$,B8:_$9$k>l9g$,$"$k$N$G!"HO0O$r$"$i$+$8$a8BDj$7$F$*$/(B
        tmp.range <- xx[log((sfun(xx)-target.pers[i])^2)<3]
        a <- optimize(tmpfunc,lower=min(tmp.range),upper=max(tmp.range),
                      sfun.tmp=sfun,target.per.tmp=target.pers[i],
                      tol=0.00001)
#        a <- optim(0.5,tmpfunc,lower=0,upper=max(f.var),sfun.tmp=sfun,target.per.tmp=target.pers[i])        
#        a <- uniroot(tmpfunc,lower=0,upper=max(f.var),sfun.tmp=sfun,target.per.tmp=target.pers[i])
#        a <- nlm(tmpfunc,0.5,sfun.tmp=sfun,target.per.tmp=target.pers[i],iterlim=1000)
#        a <- nibun(tmpfunc,lower=0,upper=max(f.var),sfun.tmp=sfun,target.per.tmp=target.pers[i],
#                      tol=0.00001)

        if(round(a$objective,5)<0.1){
          F.multiplier[i] <- round(a$minimum,5)
#          browser()
        }
        else{
          F.multiplier[i] <- NA
        }
      }
      else{
        if(min(sfun(xx))<target.pers[i]){
          F.multiplier[i] <- paste2(">",max(f.var))
#          browser()
        }
        else{
          F.multiplier[i] <- paste2("<",min(f.var))
#          browser()          
        }        
      }
    }
    names(F.multiplier) <- target.pers

    if(is.plot){
      points(as.numeric(F.multiplier),target.pers,pch=4,col=2)
      abline(h=target.pers,col=2,lty=2)
#      text(as.numeric(F.multiplier)+0.05,target.pers,paste2("(",round(F.multiplier,2),",",round(target.pers,2),")"),
#           adj=0,col=1)
    }
  }
  else{
    F.multiplier <- NA
  }
  return(F.multiplier)  
}

