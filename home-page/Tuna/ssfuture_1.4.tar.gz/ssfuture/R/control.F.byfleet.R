control.F.byfleet <-
function(faa,fleet.F=NULL){
  if(is.null(fleet.F)) fleet.F <- rep(1,dim(faa$faa.array)[[3]])
  
  if(length(fleet.F)!=dim(faa$faa.array)[[3]]){
    cat("warning: NOT same length between fleet.F and faa$faa.array\n")
  }
  
  faa.array.tmp <- faa$faa.array
  for(i in 1:length(fleet.F)){
    faa.array.tmp[,,i] <- faa$faa.array[,,i]*fleet.F[i]
  }
  faa.tmp  <- apply(faa.array.tmp,c(1,2),sum)

  faa$faa <- faa.tmp
  faa$faa.array <- faa.array.tmp
  return(faa)
}

