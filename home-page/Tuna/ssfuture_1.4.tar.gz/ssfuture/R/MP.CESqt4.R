MP.CESqt4 <-
function(cl,args.mp=list(
                           # $BI,$:I,MW$J%*%W%7%g%s(B
                           Fcur1=NULL, # CurrentF=$B5y6HJLG/NpJL(BF$B$N%Y%/%H%k!#4IM}A0(B <- Fyear1 $B$rM?$($l$P(Bdo.projection$B$G7W;;$7$F$/$l$k(B
                           Fcur2=NULL, # CurrentF=$B5y6HJLG/NpJL(BF$B$N%Y%/%H%k!#4IM}8e(B <- Fyear2 $B$rM?$($l$P(Bdo.projection$B$G7W;;$7$F$/$l$k(B
                           start.regulation=2011, # $B4IM}$r<B;\$9$kG/(B
                           # $B4pK\E*$K$O!"(Bmake.partcacharg$B$NJV$jCM$rMQ$$$k(B
                           CES.multi=1,
                           # $BI,$:$7$bI,MW$G$J$$%*%W%7%g%s(B
                           CES.plus=0,
                           CES.multi.year=NULL,# 1000$BG/0J>e$N>-MhM=B,$r$9$k$H$3$N%*%W%7%g%s$G%(%i!<=P$k$N$GCm0U(B
                           # $BFbIt$G7W;;$5$l$k$b$N!#MbG/$K$b0z$-EO$5$l$k0z?t(B
                           CES0=NULL,
                           # $B5y3MNL$N%-%c%C%T%s%0$N%*%W%7%g%s(B 
                           catch.capping=NULL
                           # or list(reg.fleet=c(2,3), #regulation$B$r$9$k5y6H(B
                           #         upper.catch=c(3000,1000))# $B5y3MNLCM$OKh;MH>4|(B
                           #up.limit=NULL, #$B;H$o$l$F$$$J$$(B                          
                           )){
  qt.label <- c(0,0.25,0.5,0.75)
  current.season <- get.qtcode(cl$timing[1],qt.label=qt.label)
  
  if(is.null(args.mp$CES.plus)){
    args.mp$CES.plus <- 0
  }

  if(is.null(args.mp$CES.multi.year)){
    args.mp$CES.multi.year <- rep(1,1000)
  }  

#  if(is.null(args.mp$gm)){
#    args.mp$gm <- FALSE
#  }

  year.label <- as.numeric(rownames(cl$faat))

#  args.mp$CES0 <- args.mp$CES.qt[current.season,]
  # $B4IM}A0(B
  # $B$I$s$J>l9g$G$b(B new.partial.ratio$B$KCM$rF~$l$k!#!a(B> $BK\BN$N(Bpartial.catch$B$O>e=q$-$5$l$k(B
  if(as.numeric(cl$timing[1])<args.mp$start.regulation){
    args.mp$CES0 <- apply(args.mp$Fcur1,1,sum)
    args.mp$new.partial.ratio <- args.mp$Fcur1        
  }
  else{ # $B4IM}8e(B
    args.mp$CES0 <- apply(args.mp$Fcur2,1,sum)
    args.mp$new.partial.ratio <- args.mp$Fcur2    
  }
  tmp.CES <- args.mp$CES0 * args.mp$CES.multi * args.mp$CES.multi.year[floor(as.numeric(cl$timing[1])-cl$initial.year)+1]
    + args.mp$CES.plus  

  #------------------- catch$B$N%-%c%C%T%s%0$r9T$&>l9g(B  
  #-------------------
  args.mp$new.partial.ratio <- NULL # $B$3$N%*%W%7%g%s$G;H$&(Bnew.partial.ratio$B$OKh2s99?7$9$k(B       
  if(!is.null(args.mp$catch.capping) &&
     as.numeric(cl$timing[1])>=args.mp$start.regulation){
#    browser()
  #------ $BJQ?t$N=i4|2=(B
    reg.fleet <- args.mp$catch.capping$reg.fleet
    upper.catch <- args.mp$catch.capping$upper.catch # $B5y3MNL>e8BNL!JG/7W!K(B
    
    adjust.F <- rep(1,cl$nfleet)
    tmp.F <- sweep(args.mp$Fcur2,2,adjust.F,FUN="*")
    res <- optim(rep(1,length(reg.fleet)),# $B=i4|CM(B      
                     cal.diffpartcatch,# $B:G>.2=$9$Y$-4X?t(B
                     part.F=tmp.F,cl=cl,reg.fleet=reg.fleet,
                     upper.catch=upper.catch#upper.catch
                     )
        adjust.F[reg.fleet] <- res$par  # $B3F5y6H$X$N(Bmultipler
#        cat(cl$timing," ",round(adjust.F,2),"\n")

#      part.catch2 <- get.partialcatch(cl=cl,fleet.multi=adjust.F,part.F=args.mp$Fcur2) # $B<B:]$N5y3MNL!J$?$7$+$aMQ!K(B
    args.mp$new.partial.ratio <- sweep(args.mp$Fcur2,2,adjust.F,FUN="*")      
#    part.catch3 <- get.partialcatch(cl=cl,part.F=args.mp$new.partial.ratio) # $B<B:]$N5y3MNL!J$?$7$+$aMQ!K(B
#    cat("|",round(part.catch3[[1]])[this.season.reg.fleet]," vs ",round(this.season.upper),"\n")      

    #      cat(" Actual:",round(part.catch3[[1]][this.season.reg.fleet]),"\n")
    tmp.CES <- apply(args.mp$new.partial.ratio,1,sum)

    # $BMhG/$N;D$j$N5y3MNL$N99?7(B
#    args.mp$remaining.catch <- ifelse(remaining.catch.next>0,remaining.catch.next,0)
#    cat(cl$timing[1]," ",args.mp$remaining.catch,"\n")
  }
#  if(do.capping) tmp.CES <- tmp.CES2
  
  list(res=tmp.CES,args.mp=args.mp)
}

