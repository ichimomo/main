make.REC <-
function(condition.list,MP,args.mp){
  #cat(MP," ")
  MP.obj <- get(MP)
  MP.obj(condition.list,args.R=args.mp)
}

