REC.ss2 <-
function(cl,args.R=list(coef=c(0.75,14000000),
                         R.var=0.36,B0=60000,recruit.qt=1)){

  if(is.null(args.R$resampled)){
    args.R$resampled <- F
  }

  if(qtback(cl$timing[2])==args.R$recruit.qt){
#    if(args.R$resampled==FALSE){
      res <- Beverton.holt.ss2(sum(cl$naat.pred*cl$waa*cl$maa/1000),
                               coef=args.R$coef,B0=args.R$B0) *
                    exp(rnorm(1,mean=0,sd=sqrt(args.R$R.var))-0.5*args.R$R.var)
#      }
#   else{
#      rec.tmp <- cl$outdata$Numbers[as.numeric(rownames(cl$outdata$Numbers))<
#                                    cl$initial.year,colnames(cl$outdata$Numbers)==0]
#      rec.tmp <- as.numeric(rec.tmp)
#      rec.tmp <- rec.tmp[rec.tmp!=0]          
#      res <- rec.tmp[floor(runif(1,min=1,max=length(rec.tmp)+1))]
    }
  else{
    res <- 0
  }
  list(res=res,args.R=args.R)
}

