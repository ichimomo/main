Llogistic <-
function(len,beta1,beta2){
  (1+exp(-log(19)*(len-beta1)/beta2))^{-1}
}

