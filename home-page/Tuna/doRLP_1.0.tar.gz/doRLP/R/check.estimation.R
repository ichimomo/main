check.estimation <-
function(tmpres1,filelist){
  res <- lapply(filelist$rep,function(x) getSPR.ss(x)[[1]])

  # compare results between SS estimation and true dynamics
  ssb.array <- recruit.array <- array(0,dim=c(length(tmpres1$arglist$year.window),
                        length(filelist$rep),3))
#  browser()
  ssb.array[,,1] <- tmpres1$ssb[,1:length(filelist$rep)]
  ssb.array[,,2] <- sapply(res,function(x)x$SPB)
  ssb.array[,,3] <- (ssb.array[,,2]-ssb.array[,,1])/ssb.array[,,1]

  recruit.array[,,1] <- tmpres1$rec[,1:length(filelist$rep)] 
  recruit.array[,,2] <- sapply(res,function(x)x$Recruits)
  recruit.array[,,3] <- (recruit.array[,,2]-recruit.array[,,1])/recruit.array[,,1]
  return(list(ssb=ssb.array,recruit=recruit.array))
}

