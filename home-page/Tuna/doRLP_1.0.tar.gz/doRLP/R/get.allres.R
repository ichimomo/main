get.allres <-
function(dirs1=".",skip.grep=FALSE){
  #dirs1 <- "."
  dirs2 <- "res"
  library(sstools)
  res <- list()
  load(paste2(dirs1,"/tmpres.R"))
  res[[1]] <- tmpres
  res[[2]] <- list()
  flist <- dir(paste2(dirs1,"/",dirs2))
  res[[2]]$rep <- paste2(dirs1,"/",dirs2,"/",flist[substr(flist,1,7)=="Report_" & substr(flist,1,8)!="Report_L"])
  res[[2]]$clist <- paste2(dirs1,"/",dirs2,"/",flist[substr(flist,1,11)=="CompReport_" &
                                                     substr(flist,1,12)!="CompReport_L"])
  res[[2]]$par <- paste2(dirs1,"/",dirs2,"/",flist[substr(flist,1,4)=="ss3_" & substr(flist,1,5)!="ss3_L"])
  res[[4]] <- check.estimation(tmpres,res[[2]])
  res[[5]] <- get.pars2(res[[2]]$par,tmpres)

  if(!skip.grep){
    system(paste2("grep \"1 NA 50\" ", dirs1,"/",dirs2,"/Report_0*.sso -A 1 > effN.txt"))
    edata <- read.table("effN.txt",fill=T)
    res[[6]] <- list()
    res[[6]]$effN1 <-  edata$V4[(1:nrow(edata))%%3==1]
    res[[6]]$effN2 <-  edata$V4[(1:nrow(edata))%%3==2]
  }

  cv <- function(x){
    sd(x)/mean(x)
  }
  ssb.diff <- t(res[[4]]$ssb[,,3])
  recruit.diff <- t(res[[4]]$recruit[,,3])
  # parameters
#  x <- cbind(apply(res[[5]]$pars,2,median),apply(res[[5]]$pars,2,cv),apply(res[[5]]$diffs,2,median))
#  x1 <- x[c(1,2,4,8,10,11),]
  x1 <- t(res[[5]]$pars[,c(1,2,4,8,10,11)])
  rownames(x1) <- c("R0","F1_sel1","F1_sel2","F2_sel1","F2_sel2","F2_sel3")
  x1 <- as.data.frame.table(x1)
  res.table <- x1
  res.table <- rbind(res.table,data.frame(Var1=c("R0","F1_sel1","F1_sel2","F2_sel1","F2_sel2","F2_sel3"),
                     Var2="true",
                     Freq=c(4.6,6,2,2,1,1)))
  # CPUE
  cpues <- lapply(res[[2]]$rep,getCPUE.ss)
  cpue.cv <- sapply(cpues, function(x) x[[3]]$Npos)[3:4,]
  rownames(cpue.cv) <- c("F1_cpue","F2_cpue")
  res.table <- rbind(res.table,as.data.frame.table(cpue.cv))
  res.table <- rbind(res.table,data.frame(Var1=c("F1_cpue","F2_cpue"),
                                          Var2="true",Freq=0.2))

  pick.year <- c(10,25,40,48,49,50)
  for(i in 1:length(pick.year)){
    for(j in 1:2){
      res.table <- rbind(res.table,
                         data.frame(Var1=paste2("DR",i),
                                    Var2=ifelse(j==1,"true","est"),
                                    Freq=res[[4]]$ssb[pick.year[i],,j]/res[[4]]$ssb[1,,j]))
    }
  }

  pick.year <- c(10,25,40,48,49,50)
  for(i in 1:length(pick.year)){
    for(j in 1:2){
      res.table <- rbind(res.table,
                         data.frame(Var1=paste2("Rec",i),
                                    Var2=ifelse(j==1,"true","est"),
                                    Freq=res[[4]]$recruit[pick.year[i],,j]))
    }
  }
  res.table <- rbind(res.table,data.frame(Var1="EffN1",Var2="est",Freq=res[[6]][[1]]))
  res.table <- rbind(res.table,data.frame(Var1="EffN2",Var2="est",Freq=res[[6]][[2]]))
  res.table <- rbind(res.table,data.frame(Var1=c("EffN1","EffN2"),
                                          Var2="true",Freq=400))  

  x4 <- rbind(cbind(sapply(res[[6]],median),sapply(res[[6]],cv)),
              cbind(apply(cpue.cv,1,median)[3:4],apply(cpue.cv,1,cv)[3:4]))
  rownames(x4) <- c("EffN F1","EffN F2","CPUE1","CPUE2")
  return(list(res=res,summary=res.table,ssb.diff=ssb.diff,recruit.diff=recruit.diff))
}

