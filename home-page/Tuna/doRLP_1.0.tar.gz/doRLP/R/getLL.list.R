getLL.list <-
function(cases=1:100,folders=c("res"),old=FALSE){
  lres.list <- list()
  r0 <- scan(paste2(folders,"/orgrun_tmp/profilevalues.ss"))[-1]
  system(paste2("grep -l \"#QNAN\" " ,folders,"/res/Repor*.sso > qnan.file.txt"))
  qnan.file <- scan("qnan.file.txt",what="character")
  s <- 1
  active.a <- c(1:4,6,8,9,13,14,19,20)
  for(i in 1:length(folders)){
    for(j in 1:length(cases)){
      tmp <- dir(paste2(folders[i],"/res"))
      if(!old){
        blist <- paste2(folders[i],"/res/",
                      tmp00 <- tmp[substr(tmp,1,12)==paste2("Report_L",toshi(cases[j]),"-")])
    }
      else{
          blist <- paste2(folders[i],"/res/",
                          tmp00 <- tmp[substr(tmp,1,10+floor(log10(j)))==paste2("Report_L",cases[j],"-")])
        }
    
      if(length(tmp00)>0){
        non.na.file <- which(is.na(match(blist,qnan.file)))
        na.file <- which(!is.na(match(blist,qnan.file)))    
        blist <- blist[non.na.file]
        try.res <- try(plotLL.ss(blist,is.plot=FALSE))
        rownames(try.res) <- r0[non.na.file]
        try.res2 <- matrix(NA,length(r0),ncol(try.res))
        dimnames(try.res2) <- list(r0,colnames(try.res))
        try.res2[non.na.file,] <- try.res
        if(class(try.res2)!="try-error"){
          lres <- try.res2
          tmp <- t(lres)-apply(lres,2,min,na.rm=T)
          #      active.a <- which(apply(tmp>0.01,1,sum,na.rm=T)>0)
          lres.list[[s]] <- t(tmp[active.a,])
          names(lres.list)[s] <- paste2(folders[i],"-",cases[j])
          s <- s+1      
        }
      }}}
  save(blist,file="blist.R")
  return(lres.list)
}

