get.ssfile <-
function(res,filename="ss_simulation",ss.age=29,Nlen.ss=NULL,obs.cpue=NULL){
  nyear <- dim(res$cal)[[1]]
  nbin <- dim(res$cal)[[2]]  
  nsim <- dim(res$cal)[[3]]
  nfleet <- dim(res$cal)[[4]]

  catchf <- apply(res$wcaaf,c(1,3,4),sum) # simulationごと、漁業ごとの総漁獲量
  filename.org <- filename

#  add.year <- 1800
#  year.range <- add.year + c(1,nyear)
#  year.seq <- year.range[1]:year.range[2]
  year.seq <- res$arglist$year.seq[res$arglist$year.window]
  year.range <- range(year.seq)
  datname <- paste2(filename.org,toshi(1:nsim),".dat")
  
  for(i in 1:nsim){
    filename <- datname[i]
    cat(c("# This file was automatically produced by using R programm describing cohort-dynamics model"),"\n",file=filename) 
    cat.ss2(year.range,"\n",file=filename) # Start year
    cat.ss2(1,"\n",file=filename) # n season
    cat.ss2(12,"\n",file=filename) # Months/season
    cat.ss2(1,"\n",file=filename) # Spawning season
  
    cat.ss2(nfleet,"\n",file=filename) # Number of fleet
    cat.ss2(nfleet,"\n",file=filename) # Number of survey

    cat.ss2(1,"\n",file=filename) # N of area
    
    cat(c(paste("fleet",1:((nfleet*2)-1),"%",sep=""),
          paste("fleet",nfleet*2,"\n",sep="")),sep="",file=filename,append=T) # Number of fleet
    cat.ss2(rep(0.5,nfleet*2),"\n",file=filename) #  Timing of fishing
    cat.ss2(rep(1,nfleet*2),"\n",file=filename) #  assigned area
    cat.ss2(rep(1,nfleet),"\n",file=filename) #  unit of catch
    cat.ss2(rep(0.1,nfleet),"\n",file=filename) #  se of log catch

    nage <- res$arglist$nage
    cat.ss2(1,"\n",file=filename) #  Ngenders
    cat.ss2(ss.age,"\n",file=filename) #  n ages

    # init catch
    if(min(res$arglist$year.window)>1){
      pr.catch <- apply(catchf[1:3,i,],2,mean)
      cat.ss2(round(pr.catch,3),"\n",file=filename) # initial catch
    }
    else{
      cat.ss2(rep(0,nfleet),"\n",file=filename) # initial catch
    }

    # N of catch data
    cat.ss2(nrow(catchf[,i,,drop=F]),"\n",file=filename) # ???? option
    
    write.table.ss2(cbind(catchf[,i,],year.seq,1),
                    file=filename,col.names=FALSE,row.names=FALSE)

    cpue <- res$cpue
    
    cat.ss2(nrow(cpue[,i,,drop=F])*nfleet,"\n",file=filename) #
    
    for(j in 1:(nfleet*2)){
      cat.ss2(c(j,0,0),"\n",file=filename) #  unit of catch
    }
    if(is.null(obs.cpue)){
      obs.cpue <- res$arglist$cpue.error
    }
    for(j in 1:nfleet){
      
      write.table.ss2(cbind(year.seq,1,j+nfleet,round(cpue[,i,j],5),
                            obs.cpue[j]),
                      file=filename,col.names=FALSE,row.names=FALSE)
    }

    cat.ss2(rep(0,3),"\n",file=filename) # ???? option
    cat.ss2(30,"\n",file=filename) # ???? option

    cat.ss2(3,"\n",file=filename) # ???? option
    # population length bin
    len.bin <- res$arglist$len.bin
    pbin <- len.bin #seq(from=5,to=290)
    cat.ss2(length(pbin),"\n",file=filename) # ???? option
    cat.ss2(pbin,"\n",file=filename) # ???? option    

    cat.ss2(0,"\n",file=filename) # ???? option
    cat.ss2(0.000001,"\n",file=filename) # ???? option
    cat.ss2(0,"\n",file=filename) # ???? option    

    # population length bin
    cat.ss2(length(pbin),"\n",file=filename) # No of lengthbins  
    cat.ss2(pbin,"\n",file=filename) #
    # age bin
    cat.ss2(0,"\n",file=filename) # ???? option
    cat.ss2(nage,"\n",file=filename) # ???? option
    cat.ss2(seq(from=0,length=nage),"\n",file=filename) # ???? option    

    cat.ss2(c(0,0,2,0,0,0,0),"\n",file=filename) # ???? option

    cal <- res$cal
    len.bin <- dimnames(cal)[[2]]
    cat.ss2(nfleet,"\n",file=filename) # length bin definition
#    browser()
    cat.ss2(rep(length(len.bin),nfleet),"\n",file=filename)
    cat.ss2(rep(2,nfleet),"\n",file=filename)
    cat.ss2(rep(3,nfleet),"\n",file=filename)
    cat.ss2(rep(0.000001,nfleet),"\n",file=filename) # comp length

    cat.ss2(rep(dim(res$cal)[[1]],nfleet),"\n",file=filename)
    for(j in 1:nfleet){
      cat.ss2(len.bin,"\n",file=filename) # length bin definition
    }

    Nlen.ss2 <- matrix(0,nfleet,length(year.seq))
    if(is.null(Nlen.ss)){
      Nlen.ss2[] <- res$arglist$Nlen
    }
    if(is.vector(Nlen.ss)){
      Nlen.ss2[] <- Nlen.ss
    }
    if(is.matrix(Nlen.ss)){
      Nlen.ss2[] <- Nlen.ss[,i]
    }
    else{
      if(is.array(Nlen.ss)){
        Nlen.ss2[] <- Nlen.ss[,,i]
      }}
#    browser()

    for(j in 1:nfleet){
      write.table.ss2(cbind(j,year.seq,1,j,1,0,Nlen.ss2[j,],round(cal[,,i,j],5)),
                      file=filename,col.names=FALSE,row.names=FALSE)
    }
    
    cat.ss2(0,"\n",file=filename) # Other option????
    cat.ss2(0,"\n",file=filename) #        
    cat.ss2(999,"\n",file=filename) #
  }
  file.copy2(from="ss_simulation001.dat",to="ss0.dat")
  return(datname)
}

