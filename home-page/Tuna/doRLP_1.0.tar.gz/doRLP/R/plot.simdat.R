plot.simdat <-
function(tmpres1){
  par(mfrow=c(2,1))
  boxplot(t(tmpres1$ssb)/tmpres1$S0,ylim=c(0,1))
  for(i in 1:4) points(tmpres1$ssb[,i]/tmpres1$S0,type="l",col=2)
  matplot(apply(tmpres1$cal,c(2,4),sum),type="l",main="catch at length")
}

