calc.rel.abund <-
function(sel,Fr,na,M,waa,maa,max.age=Inf,masaba=FALSE){
  rel.abund <- rep(NA, na)
  rel.abund[1] <- 1
  for (i in 2:(na-1)) {
    rel.abund[i] <- rel.abund[i-1]*exp(-M[i-1]-sel[i-1]*Fr)
  }
  rel.abund[na] <- rel.abund[na-1]*exp(-M[na-1]-sel[na-1]*Fr)*(1-exp(-(max.age-(na-2))*(M[na]+sel[na]*Fr)))/(1-exp(-M[na]-sel[na]*Fr))

  ypr <- rel.abund*waa*(1-exp(-sel*Fr))*exp(-M/2)

  spr <- rel.abund*waa*maa
  return(list(rel.abund=rel.abund,ypr=ypr,spr=spr))
}

