get.data <-
function(nyear = 60,
                     initial.year=1800,
                     year.window=1:50,
                     year.seq=((1:nyear) + initial.year -1),
                     nage = 30,nfleet = 2,nsim = 10,
                     h = 0.8,seed=1,
                     Rsigma=0.6,R0=exp(4.6),cpue.error=rep(0.2,nfleet),
                     mut.half.age = 4,
                     Nlen=rep(400,nfleet),
                     Fall=0.15,
                    Faf=data.frame(f1=rep(Fall,nyear),
                       f2=rep(Fall*2,nyear)),
                     isYPR=FALSE,
                     growthfunc=shimose08,
                     weightfunc=kai07,
                     sel.par=rbind(c(6,-9,2,-9,-999,9), # -9部分は推定する必要ない
                                   c(2,-9,1,1,-999,-999)), 
                     Ma=rep(0.25,nage),
                     len.sample.err="no", # "no"; no error, "simple"; sample is divided into ages, "extreme"; ad-hoc sample by ages
                     Len.sample.err2=0.2,
                     cpue.b=c(1,1),
                     sel.par.sd=c(0,0), # sd for time-varying selectivity
                     sel.time=matrix(0,nfleet,nyear) # diff to add top parameter by year
                     ){

  set.seed(seed)
#  if(isTRUE(fixRdev)){
#    Rdev <- exp(rnorm(length(ssb),mean=-0.5*(Rsigma)^2,sd=Rsigma))
#  }
  
  if(length(year.seq)!=nyear) stop("length(year.seq)!=nyear")
  argname <- ls()
  arglist <- lapply(argname,function(xx) eval(parse(text=xx)))
  names(arglist) <- argname
  age.seq <- 0:(nage-1)
  mut <- 1/(1+exp(-3*((age.seq)-mut.half.age)))
  laa <- growthfunc((age.seq)+0.5)
  laa.ssb <- growthfunc((age.seq))  
  len.bin <- seq(from=5,to=max(laa)*1.5,by=2)
  nbin <- length(len.bin)  
  growth.cv <- 0.1
  
  # weight at age 
  waa <- weightfunc(laa) # + 0.5才のwaa

  # length-weight key
  len.bin.mid <- len.bin + c(diff(as.numeric(len.bin))/2,mean(diff(as.numeric(len.bin))/2))
  lwk <- weightfunc(len.bin.mid)
  # age-length key created from length-weight key
  alk <- alk.ssb <- matrix(0,nbin,nage)
  for(a in 1:nage){
    alk[,a] <- dnorm(len.bin.mid,mean=laa[a],sd=growth.cv*laa[a]) # binの真ん中の確率分布を計算
    alk.ssb[,a] <- dnorm(len.bin.mid,mean=laa.ssb[a],sd=growth.cv*laa.ssb[a]) 
    alk[,a] <- alk[,a]/sum(alk[,a])
    alk.ssb[,a] <- alk.ssb[,a]/sum(alk.ssb[,a])    
  }
  waa.ssb <- apply(sweep(alk.ssb,1,lwk,FUN="*"),2,sum)
  
  arglist$len.bin <- len.bin

  q.vec <- c(0.1,0.1)
#  Fsel <- data.frame(f1=selex24(sel.par[1,],age.seq))# change 2013/05/10
  Fsel <- data.frame(f1=selex24(sel.par[1,],age.seq+0.5))#
  
  Fsel.array <- array(NA,dim=c(nyear,nage,nfleet,nsim))
  for(s in 1:nsim){
    for(f in 1:nfleet){
      sel.rand <- rnorm(nyear,mean=sel.par[f,1],sd=sel.par.sd[f])
      sel.rand[sel.rand<0] <- 0
      sel.rand <- sel.rand + sel.time[f,]
      tmpfunc <- function(x,sel.par){
        sel.tmp <- sel.par
        sel.tmp[1] <- x
#        selex24(sel.tmp,age.seq+0.5)
        selex24(sel.tmp,age.seq)        
      }
      Fsel.array[,,f,s] <- t(sapply(sel.rand,tmpfunc,sel.par=sel.par[f,]))
  }}
#  Fay <- Faf$f1 %o% Fsel$f1
  Fay <- sweep(Fsel.array[,,1,],1,Faf[,1],FUN="*")
  if(nfleet>1){
    for(i in 2:nfleet){
#      Fsel[paste2("f",i)] <- selex24(sel.par[i,],age.seq)
#      Fay <- Fay + Faf[paste2("f",i)][,1] %o% Fsel[paste2("f",i)][,1]
      Fay <- Fay + sweep(Fsel.array[,,i,],1,Faf[,i],FUN="*")      
    }
  }
#  Fay <- Faf$f1 %o% Fsel$f1
#  if(nfleet>1){
#    for(i in 2:nfleet){
#      Fsel[paste2("f",i)] <- selex24(sel.par[i,],age.seq)
#      Fay <- Fay + Faf[paste2("f",i)][,1] %o% Fsel[paste2("f",i)][,1]
#    }
#  }  

  eq0 <- calc.rel.abund(rep(1,nage),0,nage,Ma,waa.ssb,mut)
  S0 <- sum(eq0$spr) * R0

#  eq.catch <- calc.rel.abund(apply(Fay,2,mean),1,nage,Ma,waa,mut)
#  eq.catch.list <- lapply(Fmulti <- seq(from=0.01,to=3,length=100),
#                          function(x) calc.rel.abund(apply(Fay,2,mean),x,nage,Ma,waa,mut))
#  Fmulti <- seq(from=0,to=2,length=200)
#  YPR <- list()  
#  if(isYPR==TRUE){
#    for(i in 1:nyear){
#      for(s in 1:nsim){
#        YPR[[i]] <- calYPR.simple2(waa,mut,Ma,Fay[i,,s],Fmulti,age.seq+1,waa,mut,SR.coef=(h-0.2)/0.8/h,is.ricker=F)
#    }
#  }}
                 
  recfunc <- function(ssb,S0=1000,R0=50,sigma=0.6,h=0.7,Rdev=NULL){
    if(is.null(Rdev)) Rdev <- exp(rnorm(length(ssb),mean=-0.5*(sigma)^2,sd=sigma))
    rec <- 4*h*R0*ssb/(S0*(1-h)+ssb*(5*h-1)) * Rdev
    list(Rdev=Rdev,rec=rec)
  }

  set.seed(seed+1)  
  N <- array(NA,dim=c(nyear,nage,nsim))
  ssb <- biom <- matrix(0,nyear,nsim)
#  N[1,,] <- calc.rel.abund(rep(1,nage),0,nage,Ma,waa,mut)$rel.abund * R0
  N[1,,] <- eq0$rel.abund * R0   
  ssb[1,] <- sum(N[1,,1]*waa.ssb*mut)
  biom[1,] <- sum(N[1,,1]*waa)
  Rdev <- rep(0,nsim)
  rec <- rep(R0,nsim) #numeric()
  for(y in 2:nyear){
    for(i in 2:(nage-1))  N[y,i,] <- N[y-1,i-1,] * exp(-Fay[y-1,i-1,]-Ma[i-1])
    N[y,nage,] <- N[y-1,nage,] * exp(-Fay[y-1,nage,]-Ma[nage]) +
                      N[y-1,nage-1,] * exp(-Fay[y-1,i-1,]-Ma[i-1])
    ssb[y,] <- apply(sweep(N[y,,],1,waa.ssb * mut,FUN="*"),2,sum,na.rm=T)
    biom[y,] <- apply(sweep(N[y,,],1,waa ,FUN="*"),2,sum,na.rm=T)
    tmp <- recfunc(ssb[y,],R0=R0,S0=S0,h=h,sigma=Rsigma)      
    N[y,1,] <- tmp$rec
    Rdev <- rbind(Rdev,tmp$Rdev)
    rec <- rbind(rec,tmp$rec)    
  }

  # observation model (catch, length, CPUE)
  wcaaf <- wcaaf.cal <- caaf <- vul.num <- array(NA,dim=c(nyear,nage,nsim,nfleet))
  cal.true <- cal <- array(0,dim=c(nyear,nbin,nsim,nfleet))
  dimnames(cal) <- list(year.seq,len.bin,1:nsim,1:nfleet)
  cpue.true <- cpue.bias <- array(NA,dim=c(nyear,nsim,nfleet))
  
  for(y in 1:nyear){
    for(f in 1:nfleet){
      for(a in 1:nage){
#        vul.num[y,a,,f] <- Fsel[a,f]/(Fay[y,a]+Ma[a])*(1-exp(-Fay[y,a]-Ma[a]))*N[y,a,]
        vul.num[y,a,,f] <- Fsel.array[y,a,f,]/(Fay[y,a,]+Ma[a])*(1-exp(-Fay[y,a,]-Ma[a]))*N[y,a,]        
        caaf[y,a,,f] <- Faf[y,f]*vul.num[y,a,,f]        
        wcaaf[y,a,,f] <- Faf[y,f]*vul.num[y,a,,f]*waa[a]
      }
    }}

  for(y in 1:nyear){
    for(f in 1:nfleet){
      tmp <- caaf[y,,,f]/apply(caaf[y,,,f],2,sum)
      age.sample.num <- apply(tmp,2,function(x) rmultinom(1,Nlen[f],x))
      for(a in 1:nage){  
        tmp <- sapply(caaf[y,a,,f],function(x){ x * alk[,a]})  # tmp ; catch at length, age, fleet
        cal.true[y,,,f] <- cal.true[y,,,f] + tmp  # true catch at length

        # 年齢別の個体数に比例してサンプリングする
        #  tmp <- sweep(tmp,2,(1-rbinom(nsim,1,len.sample.err)),FUN="*")
        if(len.sample.err=="simple"){
          cal[y,,,f] <- cal[y,,,f] +  apply(tmp,2,function(x) rmultinom(1,age.sample.num[a,],x/sum(x,na.rm=T)))
        }
        else{
          if(len.sample.err=="extreme"){
            cal[y,,,f] <- cal[y,,,f] +  sweep(tmp,2,(1-rbinom(nsim,1,len.sample.err2)),FUN="*")  #apply(tmp,2,function(x) rmultinom(1,age.sample.num[a,],x/sum(x,na.rm=T)))
          }}
        wcaaf.cal[y,a,,f] <- apply(sweep(tmp,1,lwk,FUN="*"),2,sum)
      }
      if(len.sample.err=="no"){
        # usual observation error in length data is multinomial
        cal[y,,,f] <- apply(cal.true[y,,,f],2,function(x) rmultinom(1,Nlen[f],x/sum(x,na.rm=T)))
      }

#      cpue.dev <- exp(rnorm(nsim,mean=-0.5*(cpue.error[f])^2,sd=cpue.error[f]))
      cpue.dev <- exp(rnorm(nsim,mean=0,sd=cpue.error[f]))            
      cpue.true[y,,f] <- apply(vul.num[y,,,f],2,sum)*q.vec[f]*cpue.dev
      cpue.bias[y,,f] <- (apply(vul.num[y,,,f],2,sum))^(cpue.b[f])*q.vec[f]*cpue.dev
    }}

  res <- list(ssb=ssb[year.window,],biom=biom[year.window,],waa.ssb=waa.ssb,waa=waa,
              cal.true=cal.true[year.window,,,1:nfleet,drop=F],
              S0=S0,cal=cal[year.window,,,1:nfleet,drop=F],Fay=Fay,#YPR=YPR[year.window],
              wcaaf2=wcaaf[year.window,,,,drop=F],wcaaf=wcaaf.cal[year.window,,,,drop=F],
              caaf=caaf[year.window,,,,drop=F],Fsel.array=Fsel.array,
              cpue.true=cpue.true[year.window,,,drop=F],cpue=cpue.bias[year.window,,,drop=F],
              alk=alk,Rdev=Rdev,rec=rec[year.window,],arglist=arglist,mut=mut,
              wcf=apply(wcaaf.cal,c(1,3,4),sum))
  class(res) <- "simdat"
  invisible(res)
}

