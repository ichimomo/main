rep.ss3.mc <-
function(datfiles=NULL,is.likeprof=FALSE,use.wine=TRUE,folder.name="res",what.do=TRUE,mc=1,...){

  doss3 <- function(how.many=1,ss3.arg="",use.wine=FALSE){
  for(i in 1:how.many){
    if(.Platform$OS.type=="unix" && use.wine==FALSE){
      system("cp ss3.par SS3.PAR")        
      system(paste("ss3 ",ss3.arg))
    }
    else{
      if(.Platform$OS.type=="unix" && use.wine==TRUE){
        system("cp ss3.par SS3.PAR")        
        system(paste("wine ss3.exe -nox -nohess",ss3.arg))        
      }
      else{
        shell(paste("ss3.exe -nohess ",ss3.arg))
    }}
  }
}


  do.likeprof.OM <- function(startn=NULL,endn=NULL,initialize=TRUE,is.plot=FALSE,folder.name=".",
                        sp.code=1,...){
 
  if(initialize==TRUE){
      #          system("cp runnumber.ss.zero runnumber.ss")
    cat(0,file="runnumber.ss")      
  }
  parms <- scan("profilevalues.ss")
  nparms <- length(parms)-1

  parfiles <- paste2(folder.name,"/ss3_L_",sp.code,"-",tmp <- toshi(1:nparms),".par")
  repfiles <- paste2(folder.name,"/Report_L",sp.code,"-",tmp,".sso")
  compfiles <- paste2(folder.name,"/CompReport_L",sp.code,"-",tmp,".sso")
    
  if(is.null(startn)|is.null(endn)){
    startn <- 1
    endn <- nparms
  }
  for(i in startn:endn){
    #      system("wine ss3.exe")
    doss3(...)
    #      system(paste2("cp Report.sso Report_L",i,".sso"))
    #      system(paste2("cp CompReport.sso CompReport_L",i,".ss"))
    #      system(paste2("cp ss3.par ss3-L",i,".par"))
    file.copy2(from="ss3.par",to=parfiles[i])
    file.copy2(from="Report.sso",to=repfiles[i])
    file.copy2(from="CompReport.sso",to=compfiles[i])      
  }
  if(is.plot) allplot.ss(repfiles,length.on=F)
#    LL <- plotLL.ss(repfiles,is.plot=F)
#    rownames(LL) <- parms[-1]
#    invisible(LL)
    invisible(list(parfiles,repfiles,compfiles))    
}

  do.ss3.mc <- function(config){
    if(.Platform$OS.type=="unix"){
      system(paste2("cp -r orgrun_tmp ",config$wd))
    }
    else{
      system(paste2("xcopy orgrun_tmp ",config$wd," /I"))    
    }
    setwd(config$wd)
    
    if(isTRUE(config$what.do)) what.do <- 1:length(config$datfiles)

    file.copy2(from=config$datfiles,to="ss0.dat")
    doss3(...,use.wine=use.wine)
    file.copy2(from="ss3.par",to=config$parfiles)
    file.copy2(from="Report.sso",to=config$repfiles)
    file.copy2(from="CompReport.sso",to=config$compfiles)
    LP <- list()
    if(is.likeprof){
      file.copy2(from="BLUE.CTL",to="BLUE_org.CTL")            
      file.copy2(from="BLUE_LP.CTL",to="BLUE.CTL")      
      LP[[i]] <- do.likeprof.OM(startn=NULL,endn=NULL,initialize=TRUE,is.plot=FALSE,
                                sp.code=config$wd,use.wine=config$use.wine,
                                folder.name=paste2("../",config$folder.name))
      file.copy2(from="BLUE_org.CTL",to="BLUE.CTL")            
    }
    setwd("../")
    return(LP)
  }
    
  exit.function <- function(){
    file.copy2(from="BLUE_org.CTL",to="BLUE.CTL")                
  }

  if(is.likeprof) on.exit(exit.function())
  
  nboot <- length(datfiles)
  parfiles <- paste2("../",folder.name,"/ss3_",tmp <- toshi(1:length(datfiles)),".par")
  repfiles <- paste2("../",folder.name,"/Report_",tmp,".sso")
  compfiles <- paste2("../",folder.name,"/CompReport_",tmp,".sso")
  datfiles <- paste2("../",datfiles)

  config.list <- as.list(1:nboot)
  config.list <- lapply(config.list,as.list)
  for(i in 1:nboot){
    config.list[[i]]$wd <- toshi(i)
    config.list[[i]]$parfiles <- parfiles[i]
    config.list[[i]]$compfiles <- compfiles[i]
    config.list[[i]]$repfiles <- repfiles[i]
    config.list[[i]]$use.wine <- use.wine
    config.list[[i]]$datfiles <- datfiles[i]
    config.list[[i]]$folder.name <- folder.name
    config.list[[i]]$is.likeprof <- is.likeprof
  }
  
  if(mc<2){
    res <- lapply(config.list,do.ss3.mc)
  }
  else{
    library(snowfall)
#    browser()
    sfInit(parallel=TRUE,cpus=mc)
    sfLibrary(sstools)              
    res <- sfLapply(config.list,do.ss3.mc)
    sfStop()    
  }

  return(list(par=parfiles,rep=repfiles,comp=compfiles,res=res))
}

