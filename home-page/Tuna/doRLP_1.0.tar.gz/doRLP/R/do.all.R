do.all <-
function(is.plot=TRUE,folder.name="res",is.likeprof=FALSE,
                   what.do=TRUE,...){
  library(sstools)
  if(file.exists(folder.name)) unlink(folder.name,recursive=TRUE)
  dir.create(folder.name)

  tmpres <- get.data(...)
  save(tmpres,file="tmpres.R")
  # create ssfiles
  datfiles <- get.ssfile(tmpres,filename=paste2(folder.name,"/ss_simulation"))
  # do SS estimation
  filelist <- rep.ss3(use.wine=TRUE,datfiles=datfiles,is.likeprof=is.likeprof,what.do=what.do,folder.name=folder.name)
  #  filelist <- rep.ss3(use.wine=TRUE,datfiles=datfiles,is.likeprof=TRUE)
  ssb.diff <- check.estimation(tmpres,filelist)
  est.pars <- get.pars2(filelist$par,tmpres)

  if(is.plot){
#    par(mfrow=c(3,1))
    boxplot(t(tmpres$ssb)/tmpres$S0,ylim=c(0,1))
    for(i in 1:4) points(tmpres$ssb[,i]/tmpres$S0,type="l",col=2)
    matplot(apply(tmpres$cal,c(2,4),sum),type="l",main="catch at length")    
    boxplot(t(ssb.diff[,,3]),ylim=c(0,2))
    abline(h=0,col=2)
  }
  return(list(tmpres,datfiles,filelist,ssb.diff,folder.name))
}

