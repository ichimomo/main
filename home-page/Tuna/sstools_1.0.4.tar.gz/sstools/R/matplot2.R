matplot2 <-
function(...){
  matplot(type="l",col="gray",lty=1,,...)
}

