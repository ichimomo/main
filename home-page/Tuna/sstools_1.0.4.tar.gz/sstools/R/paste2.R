paste2 <-
function(x,...){
  paste(x,sep="",...)
}

