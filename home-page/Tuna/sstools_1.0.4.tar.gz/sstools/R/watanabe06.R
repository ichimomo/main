watanabe06 <-
function(len){
  0.000012*(len)^3.08
}

