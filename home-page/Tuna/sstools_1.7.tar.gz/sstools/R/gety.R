gety <-
function(list){
  list$x
}

