mod2 <-
function(x,y){
  ifelse(x%%y==0,y,x%%y)
}

