plot.snail <-
function(repfile="ss2.rep",qt=4){
  faa <- calFAA.ss2(repfile,qt=qt,is.plot=F)
  tmp <- getSPR.ss2(repfile)[[1]]
#  ssb <- tmp$"Bio_Smry"
  ssb <- tmp$"SPB"  
  names(ssb) <- tmp$Year
  res <- list(faa=apply(faa$faa,1,mean),ssb=ssb)
  plot(res$faa,res$ssb,type="b",xlab="Average F",ylab="SSB")
}

