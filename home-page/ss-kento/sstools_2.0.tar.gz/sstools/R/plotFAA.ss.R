plotFAA.ss <-
function(faa,col.var=1:100,lty.var=rep(1,100),lwd.var=rep(1,100),
                       ptype=rep("b",100),nline=-1,fleet.name=NA,
                       repfile.legend=NULL,by.age=TRUE){
  nage <- dim(faa[[1]]$faa.array)[[2]]
  nfleet <- dim(faa[[1]]$faa.array)[[3]]
  if(by.age)  setncol(nage) else setncol(nfleet)
  if(!by.age){
    for(i in 1:length(faa)){
#      faa[[i]]$faa <- apply(faa[[i]]$faa.array[-1:-2,,],c(1,3),mean)
      faa[[i]]$faa <- apply(faa[[i]]$faa.array[-1:-2,,],c(1,3),mean) # VIRG$B$H(BINIT$B$rH4$/(B        
    }
  }

  #---------- legend -----
  nplot()
  if(is.null(repfile.legend)) repfile.legend <- sapply(faa,function(x) x[[8]])
  legend("topleft",legend=repfile.legend,col=col.var,lty=lty.var,lwd=lwd.var,ncol=2,bty="n")

  #---------- PLOT1 (by age)
  years <- as.numeric(rownames(faa[[1]]$faa))  
  for(i in 1:dim(faa[[1]]$faa)[[2]]){
#    faa.mat <- sapply(faa,function(x) x$faa[,i])
    faa.mat <- sapply(faa,function(x) x$faa[-1:-2,i])
    x <- rowtapply(faa.mat)
    matplot(unique(floor(years))[-1:-2],x,ylab="",xlab="",
            col=col.var,lty=lty.var,lwd=lwd.var,type="l",ylim=c(0,max(x,na.rm=T)))
    if(by.age) title(paste("Age",dimnames(faa[[1]]$faa.array)[[2]][i]))
    else title(paste("Fleet ",dimnames(faa[[1]]$faa.array)[[3]][i]))

    if(i%%10==9){
      if(by.age)
        mtext(side=3,line=0.5,adj=0.1,"@ F at age by year",outer=T)
      else
        mtext(side=3,line=0.5,adj=0.1,"@ F by fleet (average through all ages) ",outer=T)      }
  }
}
