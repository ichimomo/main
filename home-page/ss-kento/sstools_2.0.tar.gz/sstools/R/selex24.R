selex24 <-
function(x,len.bin){
  max.x1 <- max(len.bin)+rev(diff(len.bin))[1]/2
  bin.w <- diff(len.bin)[1]
#  len.bin <- len.bin + bin.w/2
  tx <- numeric()
  tx[1] <- x[1]
  tx[2] <- tx[1]+bin.w+(0.99*max.x1-tx[1]-bin.w)/(1+exp(-x[2])) # $B$3$N<0$K$h$j!"(Bx[1]$B$H(Bx[2]$B$O9b$$Aj4X$r;}$D(B->$B$I$A$i$+$O8GDj(B
  tx[3:4] <- exp(x[3:4])
  tx[5:6] <- 1/(1+exp(-x[5:6]))
  asc <- exp(-((len.bin-tx[1])^2/tx[3]))
  des <- exp(-((len.bin-tx[2])^2/tx[4]))
  min.x <- min(len.bin)+bin.w/2
  min.x <- exp(-((min.x-tx[1])^2/tx[3]))
  max.x <- exp(-((max.x1-tx[2])^2/tx[4]))  
  
  peak.x <- 1
  
  if(x[5]>-999){
    as.d <- (tx[5]+(1-tx[5])*(asc-min.x)/(peak.x-min.x))
  }
  else{
    as.d <- asc    
  }
  if(x[6]>-999){
    des.d <- (tx[6]+(1-tx[6])*(des-max.x)/(peak.x-max.x))
  }
  else{
    des.d <- des
  }

  join1 <- 1/(1+exp(-(20*(len.bin-tx[1])/(1+abs(len.bin-tx[1])))))
  join2 <- 1/(1+exp(-(20*(len.bin-tx[2])/(1+abs(len.bin-tx[2])))))

  return(as.d*(1-join1)+join1*(1*(1-join2)+des.d*join2))
}
