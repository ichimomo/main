getAgecomp.ss.2 <-
function(repfile="ss2.rep",cl=NULL,tb=NULL,
                                                compfile=NULL){ #target.line=NULL,
  a <- read.csv(repfile, nrow = 1, colClasses = "character", 
        header = F)
    if ((is.ss2.2(repfile) && substr(a[1, 1], 16, 20) > "2.00o") || 
        (is.ss3(repfile) && vnumber.ss3(repfile) < 3.03)) {
        name.tmp <- c("year", "season", "fleet", "rep", "pick_gender", 
            "kind", "mkt", "ageerr", "gender", "Lbin_lo", "Lbin_hi", 
            "bin", "obs", "exp", "Pearson", "N", "effN", "like", 
            "Used")
    }
    else {
        if(is.ss3(repfile)){

            #---------- compatibility for ss version
            if(vnumber.ss3(repfile) >= 3.03){
                name.tmp <- c("year", "season", "fleet", "rep", 
                  "pick_gender", "kind", "Part", "ageerr", "gender", 
                  "Lbin_lo", "Lbin_hi", "bin", "obs", "exp", 
                  "Pearson", "N", "effN", "Like", "Cum_obs", 
                  "Cum_exp", "Used")
                type.tmp <- c("character", rep("numeric", 4), "character", 
                              rep("numeric", length(name.tmp) - 6))                
            }
            if(vnumber.ss3(repfile)>=3.2){
                name.tmp <- c("year", "season", "fleet", "rep", 
                              "pick_gender", "kind", "Part", "ageerr", "gender", 
                              "Lbin_lo", "Lbin_hi", "bin", "obs", "exp", 
                              "Pearson", "N", "effN", "Like", "Cum_obs", 
                              "Cum_exp", "SuprPer", "Used?")
                type.tmp <- c("character", rep("numeric", 4), "character", 
                              rep("numeric", length(name.tmp) - 8), rep("character",2))                
            }
            if(vnumber.ss3(repfile)>=3.24){
                name.tmp <- c("year", "season", "year.s","fleet", "rep", 
                              "pick_gender", "kind", "Part", "ageerr", "gender", 
                              "Lbin_lo", "Lbin_hi", "bin", "obs", "exp", 
                              "Pearson", "N", "effN", "Like", "Cum_obs", 
                              "Cum_exp", "SuprPer", "Used?")
                type.tmp <- c("character",rep("numeric", 5), "character", 
                              rep("numeric", 14), rep("character",2))                                
            }
            #------------------
            
            if (is.null(compfile)) {
                stop(message = "This version is newer than 3.30.  Please specify length composition file, named \"CompReport.SSO\" with argument of \"compfile=\"!")
            }
            else {
                repfile <- compfile
                cl <- count.fields(repfile, blank.lines.skip = FALSE)
                tb <- read.table(repfile, fill = T, col.names = paste("V", 
                  1:max(cl), sep = ""), as.is = T, blank.lines.skip = FALSE)
            }
        }
        else {
            # for SS2
            name.tmp <- c("year", "season", "fleet", "rep", "pick_gender", 
                "kind", "mkt", "ageerr", "gender", "Lbin_lo", 
                "Lbin_hi", "bin", "obs", "exp", "Pearson", "N", 
                "effN", "Used")
        }
    }

    if (is.ss3(repfile)) {
        gyou.margin <- 2
    }
    else {
        gyou.margin <- 0
    }
    if (is.null(cl)) {
        cl <- count.fields(repfile, blank.lines.skip = FALSE)
    }
    if (is.null(tb)) {
        tb <- read.table(repfile, fill = T, col.names = paste("V", 
            1:max(cl), sep = ""), as.is = T, blank.lines.skip = FALSE)
    }
    res <- find.and.read.table2("Composition_Database", skipline = 1, 
        gyou = NULL, table.property = cl, tb = tb, gyou.margin = gyou.margin, 
        outfile = repfile, h = FALSE, is.ss2 = TRUE, fill = T, 
        as.is = T, colClasses = type.tmp, col.names = name.tmp)
    res


}
