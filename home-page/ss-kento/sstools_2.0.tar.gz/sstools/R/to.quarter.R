to.quarter <-
function (month) 
{
    ceiling(month/3)
}
