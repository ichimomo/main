vBgrowth <-
function(age,lmax=200,lmin=20,Amax=15,Amin=0,K=0.2){
    linf <- lmin + (lmax - lmin)/(1 - exp(-K * (Amax - Amin)))
    linf + (lmin - linf) * exp((-K) * (age - Amin))
}
