nplot <-
function () 
{
    plot(1:10, type = "n", ylab = "", xlab = "", axes = F)
}
