kai07inv <-
function (W) 
{
    exp((log(W) - log(1.7117 * 10^{
        -5
    }))/3.0382)
}
