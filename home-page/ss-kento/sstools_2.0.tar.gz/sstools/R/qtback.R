qtback <-
function (num) 
{
    (as.numeric(num) - floor(as.numeric(num))) * 4 + 1
}
