BHfunc <-
function(ssb,steepness=0.7,r0=100,b0=100){
  y0 <- 4*steepness*ssb*r0/(b0*(1-steepness)+ssb*(5*steepness-1))
}
