to.num <-
function (x) 
{
    as.numeric(as.character(x))
}
